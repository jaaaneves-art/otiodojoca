(function () {
  var root = document.documentElement;

  /* ---------- MODO ESCURO ---------- */
  function setTheme(t) {
    if (t === 'dark') root.classList.add('dark'); else root.classList.remove('dark');
    try { localStorage.setItem('otj-theme', t); } catch (e) {}
  }
  try {
    var saved = localStorage.getItem('otj-theme');
    if (saved) setTheme(saved);
    else if (window.matchMedia && matchMedia('(prefers-color-scheme: dark)').matches) setTheme('dark');
  } catch (e) {}

  /* ---------- VOLTAR AO TOPO ---------- */
  var btt = document.getElementById('backTop');
  if (btt) {
    window.addEventListener('scroll', function () {
      btt.classList.toggle('show', window.scrollY > 500);
    }, { passive: true });
    btt.addEventListener('click', function () { window.scrollTo({ top: 0, behavior: 'smooth' }); });
  }

  /* ---------- PESQUISA ---------- */
  var idx = window.SEARCH_INDEX || [];
  function norm(s) { return s.normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase(); }
  function OV() { return document.getElementById('searchOverlay'); }
  function INP() { return document.getElementById('searchInput'); }
  function RES() { return document.getElementById('searchResults'); }

  function openS() { var ov = OV(); if (ov) { ov.classList.add('open'); setTimeout(function () { var i = INP(); i && i.focus(); }, 30); } }
  function closeS() { var ov = OV(); if (ov) { ov.classList.remove('open'); var i = INP(); if (i) i.value = ''; var r = RES(); if (r) r.innerHTML = ''; } }

  function esc(s) { return s.replace(/[&<>"]/g, function (c) { return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;' }[c]; }); }

  function run() {
    var inp = INP(), res = RES();
    if (!inp || !res) return;
    var raw = inp.value.trim();
    var q = norm(raw);
    if (q.length < 2) { res.innerHTML = ''; return; }
    var terms = q.split(/\s+/);
    var hits = [];
    for (var i = 0; i < idx.length; i++) {
      var e = idx[i];
      var ok = true;
      for (var k = 0; k < terms.length; k++) { if (e.n.indexOf(terms[k]) < 0) { ok = false; break; } }
      if (ok) { hits.push(e); if (hits.length >= 80) break; }
    }
    if (!hits.length) { res.innerHTML = '<p class="no-res">Sem resultados para \u201c' + esc(raw) + '\u201d.</p>'; return; }
    var groups = {}, order = [];
    hits.forEach(function (h) { if (!groups[h.v]) { groups[h.v] = []; order.push(h.v); } groups[h.v].push(h); });
    var html = '<p class="sr-count">' + hits.length + ' resultado' + (hits.length > 1 ? 's' : '') + '</p>';
    order.forEach(function (v) {
      html += '<div class="sr-group"><p class="sr-vol">' + esc(v) + '</p>';
      groups[v].forEach(function (h) {
        var href = h.u + (h.a ? ('#' + h.a) : '');
        html += '<a class="sr-item" href="' + href + '">' + esc(h.s) + '</a>';
      });
      html += '</div>';
    });
    res.innerHTML = html;
  }

  document.addEventListener('click', function (e) {
    if (e.target.closest('#themeToggle')) { setTheme(root.classList.contains('dark') ? 'light' : 'dark'); return; }
    if (e.target.closest('#searchToggle')) { openS(); return; }
    if (e.target.closest('#searchClose')) { closeS(); return; }
    if (e.target && e.target.id === 'searchOverlay') { closeS(); return; }
  });
  document.addEventListener('keydown', function (e) {
    if (e.key === 'Escape') closeS();
    if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === 'k') { e.preventDefault(); openS(); }
  });
  document.addEventListener('input', function (e) {
    if (e.target && e.target.id === 'searchInput') run();
  });
})();
