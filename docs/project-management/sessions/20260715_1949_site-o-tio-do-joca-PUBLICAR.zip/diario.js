/* ============================================================
   O Tio do Joca — Diário da Horta + Estatísticas
   Registo pessoal do que se semeia, colhe e observa.
   Guardado no aparelho (localStorage). As fotos são reduzidas
   para não encher o armazenamento.
   ============================================================ */
(function () {
  "use strict";

  var K = "otj_diario";
  function ler() { try { return JSON.parse(localStorage.getItem(K)) || []; } catch (e) { return []; } }
  function guardar(v) { try { localStorage.setItem(K, JSON.stringify(v)); return true; } catch (e) { alert("Não foi possível guardar — o armazenamento pode estar cheio. Tenta apagar registos antigos ou fotos."); return false; } }
  var reg = ler();

  var TIPOS = {
    semeei:   { n: "Semeei",   i: "🌱" },
    plantei:  { n: "Plantei",  i: "🪴" },
    reguei:   { n: "Reguei",   i: "💧" },
    adubei:   { n: "Adubei",   i: "🌿" },
    tratei:   { n: "Tratei",   i: "🧴" },
    podei:    { n: "Podei",    i: "✂️" },
    colhi:    { n: "Colhi",    i: "🧺" },
    observei: { n: "Observei", i: "👁️" },
    outro:    { n: "Outro",    i: "📌" }
  };
  var UNIDADES = ["kg", "g", "unidades", "dúzias", "molhos", "cestos", "frascos", "litros", "réstias", "ramos"];
  var MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function hojeISO() { var d = new Date(), m = ("0" + (d.getMonth() + 1)).slice(-2), dia = ("0" + d.getDate()).slice(-2); return d.getFullYear() + "-" + m + "-" + dia; }
  function fmtData(iso) { var p = iso.split("-"); return (+p[2]) + " de " + MESES[+p[1] - 1]; }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  function numFmt(n) { return n % 1 === 0 ? String(n) : n.toFixed(1).replace(".", ","); }

  // ---- reduzir a foto antes de guardar ----
  function reduzFoto(file, cb) {
    if (!file) { cb(null); return; }
    var r = new FileReader();
    r.onload = function () {
      var img = new Image();
      img.onload = function () {
        var max = 420, w = img.width, h = img.height;
        if (w > h && w > max) { h = Math.round(h * max / w); w = max; }
        else if (h > max) { w = Math.round(w * max / h); h = max; }
        try {
          var c = document.createElement("canvas"); c.width = w; c.height = h;
          c.getContext("2d").drawImage(img, 0, 0, w, h);
          cb(c.toDataURL("image/jpeg", 0.6));
        } catch (e) { cb(null); }
      };
      img.onerror = function () { cb(null); };
      img.src = r.result;
    };
    r.onerror = function () { cb(null); };
    r.readAsDataURL(file);
  }

  function val(id) { var e = document.getElementById(id); return e ? e.value : ""; }
  function limparForm() {
    ["d-cultura", "d-qtd", "d-nota"].forEach(function (id) { var e = document.getElementById(id); if (e) e.value = ""; });
    var f = document.getElementById("d-foto"); if (f) f.value = "";
  }

  function adicionar() {
    var data = val("d-data") || hojeISO(),
        tipo = val("d-tipo"),
        cultura = val("d-cultura").trim(),
        qtd = val("d-qtd"),
        unidade = val("d-unidade"),
        nota = val("d-nota").trim();
    if (!cultura && !nota) { alert("Escreve pelo menos a cultura ou uma nota."); return; }
    var fi = document.getElementById("d-foto");
    var file = fi && fi.files && fi.files[0];
    var btn = document.getElementById("d-add"); if (btn) { btn.disabled = true; btn.textContent = "A guardar…"; }
    reduzFoto(file, function (foto) {
      reg.push({ id: uid(), data: data, tipo: tipo, cultura: cultura, qtd: qtd ? parseFloat(String(qtd).replace(",", ".")) : null, unidade: unidade, nota: nota, foto: foto });
      guardar(reg); limparForm(); render();
      if (btn) { btn.disabled = false; btn.textContent = "＋ Registar"; }
    });
  }
  function apagar(id) { reg = reg.filter(function (e) { return e.id !== id; }); guardar(reg); render(); }

  // ---- anos ----
  var anoSel = String(new Date().getFullYear());
  function anos() {
    var s = {}; reg.forEach(function (e) { s[e.data.slice(0, 4)] = 1; });
    var a = Object.keys(s); var y = String(new Date().getFullYear());
    if (a.indexOf(y) < 0) a.push(y);
    return a.sort().reverse();
  }
  function renderAnos() {
    var s = document.getElementById("d-ano"); if (!s) return;
    var a = anos(); if (a.indexOf(anoSel) < 0) anoSel = a[0] || String(new Date().getFullYear());
    s.innerHTML = a.map(function (y) { return '<option value="' + y + '"' + (y === anoSel ? " selected" : "") + ">" + y + "</option>"; }).join("");
  }

  // ---- estatísticas ----
  function renderStats() {
    var el = document.getElementById("d-stats"); if (!el) return;
    var doAno = reg.filter(function (e) { return e.data.slice(0, 4) === anoSel; });
    var colh = {};
    doAno.filter(function (e) { return e.tipo === "colhi" && e.cultura && e.qtd; }).forEach(function (e) {
      var k = e.cultura + "||" + (e.unidade || "unidades");
      colh[k] = (colh[k] || 0) + e.qtd;
    });
    var lista = Object.keys(colh).map(function (k) { var p = k.split("||"); return { cultura: p[0], unidade: p[1], total: colh[k] }; }).sort(function (a, b) { return b.total - a.total; });
    var maxT = lista.reduce(function (m, x) { return Math.max(m, x.total); }, 0) || 1;
    var cont = {}; doAno.forEach(function (e) { cont[e.tipo] = (cont[e.tipo] || 0) + 1; });

    var html = '<div class="d-resumo">';
    [["semeei", "🌱"], ["plantei", "🪴"], ["colhi", "🧺"]].forEach(function (t) {
      html += '<div class="d-rz"><span class="d-rz-n">' + (cont[t[0]] || 0) + '</span><span class="d-rz-l">' + t[1] + " " + TIPOS[t[0]].n + "</span></div>";
    });
    html += '<div class="d-rz"><span class="d-rz-n">' + doAno.length + '</span><span class="d-rz-l">📓 registos</span></div></div>';

    if (lista.length) {
      html += '<h3 class="d-h3">Colheitas de ' + anoSel + "</h3><div class=\"d-barras\">";
      lista.forEach(function (x) {
        var pct = Math.round(x.total / maxT * 100);
        html += '<div class="d-barra"><span class="d-b-nome">' + esc(x.cultura) + '</span>' +
          '<span class="d-b-track"><i style="width:' + pct + '%"></i></span>' +
          '<span class="d-b-val">' + numFmt(x.total) + " " + esc(x.unidade) + "</span></div>";
      });
      html += "</div>";
    } else {
      html += '<p class="d-vazio">Ainda não há colheitas registadas em ' + anoSel + '. Regista um registo do tipo «Colhi» com a quantidade, e o total do ano aparece aqui. 🧺</p>';
    }
    el.innerHTML = html;
  }

  // ---- linha do tempo ----
  function renderTimeline() {
    var el = document.getElementById("d-lista"); if (!el) return;
    if (!reg.length) { el.innerHTML = '<p class="d-vazio">O teu diário está vazio. Cada sementeira, colheita ou observação que registares fica aqui — e alimenta as estatísticas. 🌱</p>'; return; }
    var ord = reg.slice().sort(function (a, b) { return a.data < b.data ? 1 : a.data > b.data ? -1 : 0; });
    var html = "", mesAtual = "";
    ord.forEach(function (e) {
      var ma = MESES[+e.data.slice(5, 7) - 1] + " " + e.data.slice(0, 4);
      if (ma !== mesAtual) { mesAtual = ma; html += '<h3 class="d-mes">' + ma + "</h3>"; }
      var t = TIPOS[e.tipo] || TIPOS.outro;
      var q = e.qtd != null ? ' <strong>' + numFmt(e.qtd) + " " + esc(e.unidade || "") + "</strong>" : "";
      html += '<article class="d-item"><span class="d-i-icone">' + t.i + "</span>" +
        '<div class="d-i-corpo"><div class="d-i-top"><span class="d-i-tipo">' + t.n + "</span>" +
        (e.cultura ? ' — <span class="d-i-cult">' + esc(e.cultura) + "</span>" : "") + q +
        '<span class="d-i-data">' + fmtData(e.data) + "</span></div>" +
        (e.nota ? '<div class="d-i-nota">' + esc(e.nota) + "</div>" : "") +
        (e.foto ? '<img class="d-i-foto" src="' + e.foto + '" alt="" loading="lazy">' : "") +
        "</div><button class=\"d-apagar\" data-del=\"" + e.id + "\" title=\"Apagar\" aria-label=\"Apagar\">✕</button></article>";
    });
    el.innerHTML = html;
  }

  function render() { renderAnos(); renderStats(); renderTimeline(); }

  document.addEventListener("click", function (e) {
    var t = e.target;
    if (t.id === "d-add") { adicionar(); return; }
    var d = t.closest && t.closest("[data-del]");
    if (d) { if (confirm("Apagar este registo?")) apagar(d.getAttribute("data-del")); return; }
  });
  document.addEventListener("change", function (e) {
    if (e.target.id === "d-ano") { anoSel = e.target.value; renderStats(); }
  });

  function iniciar() {
    var dd = document.getElementById("d-data"); if (dd) dd.value = hojeISO();
    var su = document.getElementById("d-unidade"); if (su) su.innerHTML = UNIDADES.map(function (u) { return "<option>" + u + "</option>"; }).join("");
    var st = document.getElementById("d-tipo"); if (st) st.innerHTML = Object.keys(TIPOS).map(function (k) { return '<option value="' + k + '">' + TIPOS[k].i + " " + TIPOS[k].n + "</option>"; }).join("");
    render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
