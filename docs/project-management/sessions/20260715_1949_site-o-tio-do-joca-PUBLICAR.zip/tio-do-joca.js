/* ============================================================
   TIO DO JOCA — BETA ANIMADA
   Animações · Feedback Visual · Alma de Almanaque
   ============================================================ */

console.log("%c🌿 Tio do Joca BETA — Animações Ativas", "color:#e85d04;font-size:14px;font-weight:bold;");

/* ── Estado Global ──────────────────────────────────────── */
const ESTADO = {
  plantas: [],
  localizacao: { latitude: 41.55, longitude: -8.42, nome: "Braga, Portugal" },
  checklist: new Set(),
  dadosMeteo: null,
  ultimaAtualizacao: null
};

try {
  const rawPlantas = localStorage.getItem("plantas");
  if (rawPlantas) ESTADO.plantas = JSON.parse(rawPlantas);
  const rawLoc = localStorage.getItem("localizacao");
  if (rawLoc) ESTADO.localizacao = JSON.parse(rawLoc);
  const rawCheck = localStorage.getItem("checklist");
  if (rawCheck) ESTADO.checklist = new Set(JSON.parse(rawCheck));
} catch (e) {
  console.log("ℹ️ localStorage indisponível — memória apenas");
}

function guardarEstado() {
  try {
    localStorage.setItem("plantas", JSON.stringify(ESTADO.plantas));
    localStorage.setItem("localizacao", JSON.stringify(ESTADO.localizacao));
    localStorage.setItem("checklist", JSON.stringify([...ESTADO.checklist]));
  } catch (e) {}
}

/* ── Ícones ─────────────────────────────────────────────── */
const ICONES = {
  "Horta": "🥕", "Árvore": "🌳", "Flor": "🌼",
  "Aromática": "🌿", "Suculenta": "🌵", "Outra": "🍀"
};

/* ── Fase da Lua ────────────────────────────────────────── */
const LUAS_NOVAS = [
  { ano: 2000, mes: 1, dia: 6, jd: 2451549.5 },
  { ano: 2005, mes: 1, dia: 10, jd: 2453380.5 },
  { ano: 2010, mes: 1, dia: 15, jd: 2455211.5 },
  { ano: 2015, mes: 1, dia: 20, jd: 2457042.5 },
  { ano: 2020, mes: 1, dia: 24, jd: 2458872.5 },
  { ano: 2024, mes: 1, dia: 11, jd: 2460320.5 },
  { ano: 2024, mes: 7, dia: 5, jd: 2460496.5 },
  { ano: 2025, mes: 1, dia: 29, jd: 2460704.5 },
  { ano: 2025, mes: 7, dia: 24, jd: 2460880.5 },
  { ano: 2026, mes: 1, dia: 18, jd: 2461058.5 },
  { ano: 2026, mes: 7, dia: 6, jd: 2461227.5 }
];

const CICLO_SINODICO = 29.53058868;

function calcularJD(ano, mes, dia) {
  let y = ano, m = mes, d = dia;
  if (m <= 2) { y -= 1; m += 12; }
  const A = Math.floor(y / 100);
  const B = 2 - A + Math.floor(A / 4);
  return Math.floor(365.25 * (y + 4716)) + Math.floor(30.6001 * (m + 1)) + d + B - 1524.5;
}

function encontrarReferencia(jdAlvo) {
  let melhor = LUAS_NOVAS[0];
  let melhorDist = Math.abs(jdAlvo - melhor.jd);
  for (let i = 1; i < LUAS_NOVAS.length; i++) {
    const dist = Math.abs(jdAlvo - LUAS_NOVAS[i].jd);
    if (dist < melhorDist) { melhorDist = dist; melhor = LUAS_NOVAS[i]; }
  }
  return melhor;
}

function calcularFaseLua(ano, mes, dia) {
  const jdAlvo = calcularJD(ano, mes, dia);
  const ref = encontrarReferencia(jdAlvo);
  const dias = jdAlvo - ref.jd;
  const ciclos = dias / CICLO_SINODICO;
  let fase = ciclos - Math.round(ciclos);
  if (fase < 0) fase += 1.0;
  return fase;
}

function nomeFaseLua(fase) {
  if (fase <= 0.04 || fase >= 0.96) return { nome: "Lua Nova", tema: "lua-nova", base: "Boa para semear plantas de crescimento rápido." };
  if (fase < 0.23) return { nome: "Lua Crescente", tema: "lua-crescente", base: "Favorece crescimento aéreo e folhagem." };
  if (fase < 0.29) return { nome: "Quarto Crescente", tema: "lua-crescente", base: "Crescimento acelerado — boa época para transplantar." };
  if (fase < 0.48) return { nome: "Lua Gibosa", tema: "lua-crescente", base: "Energia forte — ideal para poda de formação." };
  if (fase < 0.55) return { nome: "Lua Cheia", tema: "lua-cheia", base: "A seiva está no auge." };
  if (fase < 0.73) return { nome: "Lua Gibosa Minguante", tema: "lua-minguante", base: "A seiva começa a descer para as raízes." };
  if (fase < 0.79) return { nome: "Quarto Minguante", tema: "lua-minguante", base: "Boa para poda, limpeza e preparação de canteiros." };
  return { nome: "Lua Minguante", tema: "lua-minguante", base: "A seiva desce para as raízes — bom para bulbos e raízes." };
}

function atualizarLua() {
  const elFase = document.getElementById("lua-fase");
  const elExp = document.getElementById("lua-explicacao");
  const elCard = document.getElementById("card-lua");
  if (!elFase || !elExp) return;

  try {
    const hoje = new Date();
    const valor = calcularFaseLua(hoje.getFullYear(), hoje.getMonth() + 1, hoje.getDate());
    const fase = nomeFaseLua(valor);

    // Animação de transição
    elFase.style.opacity = "0";
    elExp.style.opacity = "0";

    setTimeout(() => {
      const plantas = ESTADO.plantas;
      let exp = fase.base;
      if ((valor <= 0.04 || valor >= 0.96 || (valor >= 0.73 && valor < 0.79)) && plantas.some(p => p.tipo === "Horta")) exp += " As tuas hortícolas de raiz beneficiam desta fase.";
      if ((valor > 0.04 && valor < 0.48) && plantas.some(p => p.tipo === "Flor")) exp += " As tuas flores beneficiam desta fase.";
      if ((valor >= 0.29 && valor < 0.73) && plantas.some(p => p.tipo === "Horta" || p.tipo === "Árvore")) exp += " As tuas plantas de fruto estão em ponto alto de vigor.";

      elFase.textContent = fase.nome;
      elExp.textContent = exp;
      elFase.style.opacity = "1";
      elExp.style.opacity = "1";
    }, 200);

    if (elCard) {
      elCard.classList.remove("lua-cheia", "lua-nova", "lua-crescente", "lua-minguante");
      // Pequeno delay para a transição de tema ser visível
      setTimeout(() => {
        if (fase.tema) elCard.classList.add(fase.tema);
      }, 50);
    }
  } catch (e) {
    elFase.textContent = "Lua";
    elExp.textContent = "Cálculo indisponível.";
  }
}

/* ── Meteorologia ───────────────────────────────────────── */
const CODIGOS_CHUVA = [51,53,55,56,57,61,63,65,66,67,80,81,82,95,96,99];
const CODIGOS_NEVE = [71,73,75,77,85,86];

function gerarFallbackMeteo() {
  const mes = new Date().getMonth() + 1;
  if (mes >= 6 && mes <= 8) return { temperature: 28, weathercode: 0, isDay: 1, fallback: true };
  if (mes >= 12 || mes <= 2) return { temperature: 12, weathercode: 61, isDay: 1, fallback: true };
  return { temperature: 18, weathercode: 51, isDay: 1, fallback: true };
}

async function obterMeteoOnline() {
  const cfg = ESTADO.localizacao;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${cfg.latitude}&longitude=${cfg.longitude}&current_weather=true`;
    const resp = await fetch(url, { mode: 'cors', cache: 'no-cache' });
    if (!resp.ok) throw new Error(`HTTP ${resp.status}`);
    const data = await resp.json();
    if (!data.current_weather) throw new Error("Dados incompletos");
    ESTADO.dadosMeteo = { ...data.current_weather, fallback: false };
    ESTADO.ultimaAtualizacao = new Date().toISOString();
    return ESTADO.dadosMeteo;
  } catch (e) {
    console.warn("⚠ API falhou, fallback:", e.message);
    ESTADO.dadosMeteo = gerarFallbackMeteo();
    return ESTADO.dadosMeteo;
  }
}

async function alertaRega() {
  const alvo = document.getElementById("alerta-rega");
  const card = document.getElementById("card-rega");
  if (!alvo) return;

  // Estado de loading
  alvo.innerHTML = '<span class="loading-dots">A consultar</span>';

  const dados = await obterMeteoOnline();
  const temp = dados.temperature;
  const weather = dados.weathercode;
  const loc = ESTADO.localizacao.nome;
  const plantas = ESTADO.plantas;
  const temSensiveis = plantas.some(p => p.tipo === "Aromática" || p.tipo === "Flor");
  const temSuculentas = plantas.some(p => p.tipo === "Suculenta");

  let msg = `Hoje não há indicação especial de rega em ${loc}.`;
  let alertaAtivo = false;

  if (dados.fallback) msg = `[Estimado] ${msg}`;

  if (temp >= 28 && temSensiveis) {
    msg = `Dia quente em ${loc} (${temp}°C): rega plantas sensíveis ao calor.`;
    alertaAtivo = true;
  } else if (temp >= 32) {
    msg = `Onda de calor em ${loc} (${temp}°C): rega de manhã cedo ou ao entardecer.`;
    alertaAtivo = true;
  } else if (CODIGOS_CHUVA.includes(weather)) {
    msg = `Há chuva em ${loc}: evita regas adicionais${temSuculentas ? ", especialmente em suculentas" : ""}.`;
  } else if (CODIGOS_NEVE.includes(weather)) {
    msg = `Neve ou granizo em ${loc} — protege as plantas mais sensíveis.`;
  }

  // Animação de transição
  alvo.style.opacity = "0";
  setTimeout(() => {
    alvo.textContent = msg;
    alvo.style.opacity = "1";
  }, 150);

  // Pulso visual quando há alerta ativo
  if (card) {
    if (alertaAtivo) {
      card.classList.add("alerta-ativo");
    } else {
      card.classList.remove("alerta-ativo");
    }
  }
}

/* ── Tema Dia/Noite ─────────────────────────────────────── */
async function temaNoiteDia() {
  const cfg = ESTADO.localizacao;
  try {
    const url = `https://api.open-meteo.com/v1/forecast?latitude=${cfg.latitude}&longitude=${cfg.longitude}&daily=sunrise,sunset&timezone=Europe/Lisbon`;
    const resp = await fetch(url, { mode: 'cors', cache: 'no-cache' });
    if (!resp.ok) throw new Error("API indisponível");
    const data = await resp.json();
    const sunrise = new Date(data.daily.sunrise[0]);
    const sunset = new Date(data.daily.sunset[0]);
    const agora = new Date();
    aplicarTema(agora >= sunrise && agora < sunset);
  } catch (e) {
    const hora = new Date().getHours();
    aplicarTema(hora >= 6 && hora < 20);
  }
}

function aplicarTema(isDay) {
  const body = document.body;
  if (isDay) {
    body.classList.add("weather-day");
    body.classList.remove("weather-night");
  } else {
    body.classList.add("weather-night");
    body.classList.remove("weather-day");
  }
}

/* ── Checklist com Animações ────────────────────────────── */
function gerarChecklist() {
  const lista = document.getElementById("checklist");
  if (!lista) return;
  lista.innerHTML = "";

  let tarefas = ["Observar humidade do solo", "Limpar folhas secas"];
  ESTADO.plantas.forEach(p => {
    switch (p.tipo) {
      case "Aromática": tarefas.push("Colher ervas aromáticas", "Verificar vigor das aromáticas"); break;
      case "Árvore": tarefas.push("Verificar pragas nas folhas", "Observar tronco e ramos"); break;
      case "Suculenta": tarefas.push("Verificar excesso de água"); break;
      case "Flor": tarefas.push("Retirar flores murchas"); break;
      case "Horta": tarefas.push("Observar crescimento", "Verificar tutoragem"); break;
    }
  });
  tarefas = [...new Set(tarefas)];

  if (tarefas.length === 0) {
    const li = document.createElement("li");
    li.className = "planta-vazia";
    li.textContent = "✨ Nenhuma tarefa hoje — aproveita o descanso!";
    lista.appendChild(li);
    return;
  }

  tarefas.forEach((tarefa, index) => {
    const id = "tarefa-" + tarefa.replace(/\s/g, "-").toLowerCase().slice(0, 20);
    const item = document.createElement("li");
    item.style.animationDelay = `${index * 0.05}s`;
    item.className = "checklist-item";

    const cb = document.createElement("input");
    cb.type = "checkbox";
    cb.id = id;
    cb.checked = ESTADO.checklist.has(id);

    cb.addEventListener("change", () => {
      if (cb.checked) {
        ESTADO.checklist.add(id);
        item.style.opacity = "0.6";
        item.style.transform = "translateX(8px)";
      } else {
        ESTADO.checklist.delete(id);
        item.style.opacity = "1";
        item.style.transform = "translateX(0)";
      }
      guardarEstado();
    });

    const label = document.createElement("label");
    label.textContent = tarefa;
    label.setAttribute("for", id);

    item.appendChild(cb);
    item.appendChild(label);
    lista.appendChild(item);
  });
}

function limparChecklist() {
  ESTADO.checklist.clear();
  guardarEstado();
  gerarChecklist();
}

/* ── Calendário Agrícola ────────────────────────────────── */
function calendarioAgricolaResumo() {
  const alvo = document.getElementById("cal-agricola");
  if (!alvo) return;

  const mes = new Date().getMonth() + 1;
  const estacao = mes >= 3 && mes <= 5 ? "primavera" : mes >= 6 && mes <= 8 ? "verão" : mes >= 9 && mes <= 11 ? "outono" : "inverno";
  const plantas = ESTADO.plantas;

  let msg = `Estamos em ${estacao}. Observa o crescimento e saúde das tuas plantas.`;
  if (plantas.some(p => p.tipo === "Horta")) {
    if (mes >= 3 && mes <= 5) msg = "Primavera: boa época para semear e transplantar hortícolas.";
    else if (mes >= 9 && mes <= 11) msg = "Outono: ideal para hortícolas de raiz.";
    else if (mes >= 6 && mes <= 8) msg = "Verão: rega regular e sombra.";
    else msg = "Inverno: protege as hortícolas sensíveis ao frio.";
  }
  if (plantas.some(p => p.tipo === "Aromática") && mes >= 5 && mes <= 8) msg += " As aromáticas estão em fase forte de colheita.";
  if (plantas.some(p => p.tipo === "Árvore") && (mes >= 11 || mes <= 2)) msg += " Época de poda para árvores caducifólias.";
  if (plantas.some(p => p.tipo === "Flor") && mes >= 3 && mes <= 6) msg += " Primavera: semeia flores anuais.";

  // Efeito typewriter suave
  alvo.style.opacity = "0";
  setTimeout(() => {
    alvo.textContent = msg;
    alvo.style.opacity = "1";
  }, 200);
}

/* ── Plantas com Animações ──────────────────────────────── */
function atualizarListaPlantas() {
  const lista = document.getElementById("lista-plantas");
  if (!lista) return;
  lista.innerHTML = "";

  if (ESTADO.plantas.length === 0) {
    const li = document.createElement("li");
    li.className = "planta-vazia";
    li.innerHTML = "🌱 <em>Ainda não tens plantas registadas.<br>Adiciona a primeira acima!</em>";
    lista.appendChild(li);
    return;
  }

  ESTADO.plantas.forEach((planta, index) => {
    const li = document.createElement("li");
    li.className = "planta-item";
    li.style.animationDelay = `${index * 0.08}s`;
    const icone = ICONES[planta.tipo] || "🌱";
    li.innerHTML = `
      <span class="planta-icone">${icone}</span>
      <span class="planta-nome"><strong>${escapeHtml(planta.nome)}</strong></span>
      <span class="planta-tipo">${planta.tipo}</span>
      <button type="button" class="btn-remover" data-index="${index}" aria-label="Remover ${escapeHtml(planta.nome)}">✕</button>
    `;
    lista.appendChild(li);
  });

  lista.querySelectorAll("button[data-index]").forEach(btn => {
    btn.addEventListener("click", () => {
      const item = btn.closest(".planta-item");
      item.classList.add("removendo");
      setTimeout(() => removerPlanta(parseInt(btn.dataset.index, 10)), 300);
    });
  });
}

function escapeHtml(text) {
  const div = document.createElement("div");
  div.textContent = text;
  return div.innerHTML;
}

function adicionarPlanta() {
  const elNome = document.getElementById("planta-nome");
  const elTipo = document.getElementById("planta-tipo");
  if (!elNome || !elTipo) return;

  const nome = elNome.value.trim();
  const tipo = elTipo.value;
  if (!nome) {
    elNome.setAttribute("aria-invalid", "true");
    elNome.placeholder = "⚠ Introduz um nome…";
    setTimeout(() => { elNome.placeholder = "Nome da planta…"; elNome.removeAttribute("aria-invalid"); }, 2000);
    return;
  }

  if (ESTADO.plantas.some(p => p.nome.toLowerCase() === nome.toLowerCase())) {
    elNome.setAttribute("aria-invalid", "true");
    elNome.value = "";
    elNome.placeholder = `⚠ "${nome}" já existe!`;
    setTimeout(() => { elNome.placeholder = "Nome da planta…"; elNome.removeAttribute("aria-invalid"); }, 2000);
    return;
  }

  ESTADO.plantas.push({ nome, tipo });
  guardarEstado();
  elNome.value = "";
  elNome.focus();

  // Animação de adição
  atualizarListaPlantas();
  gerarChecklist();
  atualizarLua();
  alertaRega();
  calendarioAgricolaResumo();
}

function removerPlanta(index) {
  if (typeof index !== "number" || isNaN(index) || index < 0 || index >= ESTADO.plantas.length) return;
  ESTADO.plantas.splice(index, 1);
  guardarEstado();
  atualizarListaPlantas();
  gerarChecklist();
  atualizarLua();
  alertaRega();
  calendarioAgricolaResumo();
}

/* ── Localização ────────────────────────────────────────── */
function atualizarDisplayLocalizacao() {
  const el = document.getElementById("localizacao-atual");
  if (el) el.textContent = ESTADO.localizacao.nome;
}

function definirLocalizacaoManual() {
  const elLat = document.getElementById("loc-lat");
  const elLon = document.getElementById("loc-lon");
  const elNome = document.getElementById("loc-nome");
  if (!elLat || !elLon) return;

  const lat = parseFloat(elLat.value);
  const lon = parseFloat(elLon.value);
  const nome = elNome && elNome.value.trim() ? elNome.value.trim() : `Lat: ${lat.toFixed(2)}, Lon: ${lon.toFixed(2)}`;

  if (isNaN(lat) || isNaN(lon) || lat < -90 || lat > 90 || lon < -180 || lon > 180) {
    alert("Coordenadas inválidas!\nLatitude: -90 a 90\nLongitude: -180 a 180");
    return;
  }

  ESTADO.localizacao = { latitude: lat, longitude: lon, nome };
  guardarEstado();
  atualizarDisplayLocalizacao();
  alertaRega();
  temaNoiteDia();
  alert(`Localização atualizada!\n${nome}`);
}

/* ── Versão ─────────────────────────────────────────────── */
function atualizarVersao() {
  const el = document.getElementById("versao-data");
  if (el) el.textContent = " · BETA · " + new Date().toISOString().slice(0, 10);
}

/* ── Inicialização ──────────────────────────────────────── */
function iniciarJoca() {
  console.log("🚀 Inicializando Tio do Joca BETA…");

  atualizarVersao();
  atualizarDisplayLocalizacao();
  temaNoiteDia();

  atualizarListaPlantas();
  gerarChecklist();
  calendarioAgricolaResumo();

  atualizarLua();
  alertaRega();

  const btnAdd = document.getElementById("adicionar-planta");
  if (btnAdd) btnAdd.addEventListener("click", adicionarPlanta);

  const btnLimpar = document.getElementById("limpar-checklist");
  if (btnLimpar) btnLimpar.addEventListener("click", limparChecklist);

  const btnLoc = document.getElementById("btn-loc-manual");
  if (btnLoc) btnLoc.addEventListener("click", definirLocalizacaoManual);

  const elNome = document.getElementById("planta-nome");
  if (elNome) {
    elNome.addEventListener("keypress", (e) => { if (e.key === "Enter") adicionarPlanta(); });
  }

  console.log("%c🌿 Tio do Joca BETA pronto!", "color:#e85d04;font-size:14px;font-weight:bold;");
}

if (document.readyState === "loading") {
  document.addEventListener("DOMContentLoaded", iniciarJoca);
} else {
  iniciarJoca();
}
