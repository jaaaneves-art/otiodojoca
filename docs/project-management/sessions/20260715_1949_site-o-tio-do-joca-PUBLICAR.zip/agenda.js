/* ============================================================
   O Tio do Joca — Agenda Rural
   Painel diário: o tempo e os seus alertas (Open-Meteo), as
   tarefas das culturas seguidas (via culturas.js), os lembretes
   pessoais (com recorrência), a fase da lua e a estação.
   Guardado no aparelho (localStorage); o tempo precisa de rede.
   ============================================================ */
(function () {
  "use strict";

  var MESES = ["Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];
  var DIAS = ["Domingo", "Segunda", "Terça", "Quarta", "Quinta", "Sexta", "Sábado"];
  var DIAS_C = ["domingo", "segunda-feira", "terça-feira", "quarta-feira", "quinta-feira", "sexta-feira", "sábado"];

  var K_REM = "otj_agenda", K_FEI = "otj_agenda_feitos";
  function ler(k, d) { try { return JSON.parse(localStorage.getItem(k)) || d; } catch (e) { return d; } }
  function guardar(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); return true; } catch (e) { alert("Não foi possível guardar."); return false; } }
  var lembretes = ler(K_REM, []);
  var feitos = ler(K_FEI, {}); // { "YYYY-MM-DD": { chave:true } }

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function two(n) { return ("0" + n).slice(-2); }
  function iso(d) { return d.getFullYear() + "-" + two(d.getMonth() + 1) + "-" + two(d.getDate()); }
  function uid() { return Date.now().toString(36) + Math.random().toString(36).slice(2, 6); }
  var HOJE = new Date(); HOJE.setHours(12, 0, 0, 0);
  var HOJE_ISO = iso(HOJE);

  // ---------- Estação ----------
  function estacao() {
    var m = HOJE.getMonth() + 1, d = HOJE.getDate();
    if ((m === 12 && d >= 21) || m <= 2 || (m === 3 && d < 20)) return { n: "Inverno", i: "❄️" };
    if ((m === 3) || m === 4 || m === 5 || (m === 6 && d < 21)) return { n: "Primavera", i: "🌸" };
    if ((m === 6) || m === 7 || m === 8 || (m === 9 && d < 23)) return { n: "Verão", i: "☀️" };
    return { n: "Outono", i: "🍂" };
  }

  // ---------- Fase da Lua ----------
  function luaFase() {
    var syn = 29.530588853;
    var nova = Date.UTC(2000, 0, 6, 18, 14) / 86400000; // dias
    var agora = HOJE.getTime() / 86400000;
    var idade = (((agora - nova) % syn) + syn) % syn;
    var f = idade / syn;
    var nome, ic;
    if (f < 0.03 || f > 0.97) { nome = "Lua Nova"; ic = "🌑"; }
    else if (f < 0.22) { nome = "Lua Crescente"; ic = "🌒"; }
    else if (f < 0.28) { nome = "Quarto Crescente"; ic = "🌓"; }
    else if (f < 0.47) { nome = "Crescente Gibosa"; ic = "🌔"; }
    else if (f < 0.53) { nome = "Lua Cheia"; ic = "🌕"; }
    else if (f < 0.72) { nome = "Minguante Gibosa"; ic = "🌖"; }
    else if (f < 0.78) { nome = "Quarto Minguante"; ic = "🌗"; }
    else { nome = "Lua Minguante"; ic = "🌘"; }
    return { nome: nome, ic: ic, idade: Math.round(idade) };
  }

  // ---------- Tempo (Open-Meteo) ----------
  function wmo(c) {
    if (c === 0) return { i: "☀️", t: "céu limpo" };
    if (c <= 2) return { i: "🌤️", t: "pouco nublado" };
    if (c === 3) return { i: "☁️", t: "nublado" };
    if (c === 45 || c === 48) return { i: "🌫️", t: "nevoeiro" };
    if (c >= 51 && c <= 57) return { i: "🌦️", t: "chuvisco" };
    if (c >= 61 && c <= 67) return { i: "🌧️", t: "chuva" };
    if (c >= 71 && c <= 77) return { i: "❄️", t: "neve" };
    if (c >= 80 && c <= 82) return { i: "🌦️", t: "aguaceiros" };
    if (c >= 95) return { i: "⛈️", t: "trovoada" };
    return { i: "🌥️", t: "variável" };
  }

  function alertas(dia) {
    var a = [];
    if (dia.tmin <= 0) a.push({ nv: "forte", i: "🥶", t: "Geada forte — protege as plantas sensíveis e as culturas jovens." });
    else if (dia.tmin <= 3) a.push({ nv: "aviso", i: "❄️", t: "Risco de geada de madrugada — cobre o que for delicado." });
    if (dia.rajada >= 70) a.push({ nv: "forte", i: "🌬️", t: "Vento muito forte — adia pulverizações e amarra tutores e estufas." });
    else if (dia.rajada >= 50) a.push({ nv: "aviso", i: "💨", t: "Vento forte — evita pulverizar; pode partir ramos." });
    if (dia.chuva >= 10 || dia.probchuva >= 70) a.push({ nv: "aviso", i: "🌧️", t: "Chuva provável — não precisas de regar; adia a apanha e a sementeira." });
    if (dia.tmax >= 38) a.push({ nv: "forte", i: "🔥", t: "Calor extremo — rega ao amanhecer ou ao fim do dia; dá sombra às hortícolas." });
    else if (dia.tmax >= 32) a.push({ nv: "aviso", i: "🌡️", t: "Calor forte — rega fora das horas de sol e vigia a murchidão." });
    if (!a.length) a.push({ nv: "ok", i: "✅", t: "Sem alertas — bom dia para trabalhos no campo." });
    return a;
  }

  function pedirTempo() {
    var el = document.getElementById("ag-tempo");
    if (!navigator.geolocation) { el.innerHTML = tempoIndisp("Sem acesso à localização neste dispositivo."); return; }
    el.innerHTML = '<p class="ag-carrega">A obter o tempo para a tua zona…</p>';
    navigator.geolocation.getCurrentPosition(function (pos) {
      var la = pos.coords.latitude, lo = pos.coords.longitude;
      var url = "https://api.open-meteo.com/v1/forecast?latitude=" + la + "&longitude=" + lo +
        "&daily=weather_code,temperature_2m_max,temperature_2m_min,precipitation_sum,precipitation_probability_max,wind_gusts_10m_max&timezone=auto&forecast_days=6";
      fetch(url).then(function (r) { return r.json(); }).then(function (j) {
        renderTempo(j.daily);
      }).catch(function () { el.innerHTML = tempoIndisp("Não foi possível obter a previsão (sem ligação?)."); });
    }, function () { el.innerHTML = tempoIndisp("Sem permissão de localização — ativa-a para veres o tempo e os alertas."); },
      { timeout: 9000, maximumAge: 1800000 });
  }
  function tempoIndisp(msg) {
    return '<div class="ag-tempo-off"><span>🌦️</span><p>' + esc(msg) + ' As tarefas e os lembretes abaixo funcionam sem internet.</p></div>';
  }
  function renderTempo(dly) {
    var el = document.getElementById("ag-tempo"); if (!el || !dly) return;
    function diaObj(i) {
      return { tmax: Math.round(dly.temperature_2m_max[i]), tmin: Math.round(dly.temperature_2m_min[i]),
        chuva: dly.precipitation_sum[i], probchuva: dly.precipitation_probability_max ? dly.precipitation_probability_max[i] : 0,
        rajada: Math.round(dly.wind_gusts_10m_max[i]), code: dly.weather_code[i], data: dly.time[i] };
    }
    var hoje = diaObj(0), w = wmo(hoje.code), al = alertas(hoje);
    var html = '<div class="ag-hoje-tempo">' +
      '<div class="ag-t-icone">' + w.i + '</div>' +
      '<div class="ag-t-nums"><span class="ag-t-max">' + hoje.tmax + '°</span><span class="ag-t-min">' + hoje.tmin + '°</span>' +
      '<span class="ag-t-desc">' + w.t + '</span></div>' +
      '<div class="ag-t-extra"><span>💧 ' + (hoje.probchuva || 0) + '%</span><span>🌬️ ' + hoje.rajada + ' km/h</span></div></div>';
    html += '<div class="ag-alertas">';
    al.forEach(function (x) { html += '<div class="ag-alerta ag-' + x.nv + '"><span>' + x.i + '</span><p>' + x.t + "</p></div>"; });
    html += "</div>";
    // previsão
    html += '<div class="ag-prev"><h3 class="ag-prev-h">Próximos dias</h3><div class="ag-prev-grid">';
    for (var i = 1; i < dly.time.length; i++) {
      var d = diaObj(i), dw = wmo(d.code), dt = new Date(d.data + "T12:00:00");
      html += '<div class="ag-prev-d"><span class="ag-pd-dia">' + DIAS[dt.getDay()] + '</span>' +
        '<span class="ag-pd-ic">' + dw.i + '</span>' +
        '<span class="ag-pd-t">' + d.tmax + '° / ' + d.tmin + '°</span>' +
        '<span class="ag-pd-r">💧' + (d.probchuva || 0) + '%</span></div>';
    }
    html += "</div></div>";
    el.innerHTML = html;
  }

  // ---------- Feito hoje ----------
  function estaFeito(chave) { return !!(feitos[HOJE_ISO] && feitos[HOJE_ISO][chave]); }
  function alternarFeito(chave) {
    if (!feitos[HOJE_ISO]) feitos[HOJE_ISO] = {};
    if (feitos[HOJE_ISO][chave]) delete feitos[HOJE_ISO][chave]; else feitos[HOJE_ISO][chave] = true;
    guardar(K_FEI, feitos);
  }

  // ---------- Lembretes ----------
  function recDe(r) { return { uma: "uma vez", semanal: "todas as semanas", mensal: "todos os meses", anual: "todos os anos", sempre: "todos os dias" }[r] || "uma vez"; }
  function dueHoje(r) {
    if (r.rec === "sempre") return true;
    if (!r.data) return false;
    var rd = new Date(r.data + "T12:00:00");
    if (r.rec === "uma") return r.data === HOJE_ISO;
    if (r.rec === "semanal") return rd.getDay() === HOJE.getDay();
    if (r.rec === "mensal") return rd.getDate() === HOJE.getDate();
    if (r.rec === "anual") return rd.getDate() === HOJE.getDate() && rd.getMonth() === HOJE.getMonth();
    return false;
  }
  function dueEm(r, dia) { // dia: Date
    if (r.rec === "sempre") return true;
    if (!r.data) return false;
    var rd = new Date(r.data + "T12:00:00");
    if (r.rec === "uma") return r.data === iso(dia);
    if (r.rec === "semanal") return rd.getDay() === dia.getDay();
    if (r.rec === "mensal") return rd.getDate() === dia.getDate();
    if (r.rec === "anual") return rd.getDate() === dia.getDate() && rd.getMonth() === dia.getMonth();
    return false;
  }
  function addLembrete() {
    var titulo = val("ag-titulo").trim(); if (!titulo) { alert("Escreve o lembrete."); return; }
    lembretes.push({ id: uid(), titulo: titulo, data: val("ag-data") || "", rec: val("ag-rec"), nota: val("ag-nota").trim() });
    guardar(K_REM, lembretes);
    ["ag-titulo", "ag-nota"].forEach(function (i) { var e = document.getElementById(i); if (e) e.value = ""; });
    render();
  }
  function apagarLembrete(id) { lembretes = lembretes.filter(function (r) { return r.id !== id; }); guardar(K_REM, lembretes); render(); }
  function val(id) { var e = document.getElementById(id); return e ? e.value : ""; }

  // ---------- Render "Hoje" ----------
  function renderHoje() {
    var el = document.getElementById("ag-hoje"); if (!el) return;
    var itens = [];
    // tarefas das culturas
    if (window.OTJ_AGRO && typeof window.OTJ_AGRO.tarefasHoje === "function") {
      window.OTJ_AGRO.tarefasHoje().forEach(function (t, i) {
        var chave = "cult-" + t.chave + "-" + i;
        itens.push({ chave: chave, icone: t.icone, titulo: t.cultura + " — " + t.tarefa, sub: t.detalhe, tipo: "cultura" });
      });
    }
    // lembretes de hoje
    lembretes.filter(dueHoje).forEach(function (r) {
      itens.push({ chave: "rem-" + r.id, icone: "🔔", titulo: r.titulo, sub: r.nota, tipo: "lembrete" });
    });

    var reg = window.OTJ_AGRO && window.OTJ_AGRO.regiao ? window.OTJ_AGRO.regiao() : null;
    var nota = "";
    if (window.OTJ_AGRO && !window.OTJ_AGRO.temSeguidas()) {
      nota = '<p class="ag-dica">💡 Ainda não segues culturas. Vai a <a href="culturas.html">Culturas</a>, escolhe as tuas, e as tarefas do dia passam a aparecer aqui.</p>';
    }
    if (!itens.length) {
      el.innerHTML = '<p class="ag-vazio">Nada marcado para hoje. Bom descanso! ☕ Podes adicionar lembretes abaixo.</p>' + nota;
      return;
    }
    var feitosN = itens.filter(function (x) { return estaFeito(x.chave); }).length;
    var html = '<p class="ag-progresso">' + feitosN + " de " + itens.length + " concluído" + (itens.length > 1 ? "s" : "") + "</p>";
    itens.forEach(function (x) {
      var done = estaFeito(x.chave);
      html += '<label class="ag-tarefa ' + x.tipo + (done ? " feita" : "") + '">' +
        '<input type="checkbox" data-feito="' + x.chave + '"' + (done ? " checked" : "") + ">" +
        '<span class="ag-t-ic">' + x.icone + "</span>" +
        '<span class="ag-t-txt"><strong>' + esc(x.titulo) + "</strong>" + (x.sub ? "<em>" + esc(x.sub) + "</em>" : "") + "</span></label>";
    });
    el.innerHTML = html + nota;
  }

  // ---------- Render lembretes ----------
  function renderLembretes() {
    var el = document.getElementById("ag-lista"); if (!el) return;
    if (!lembretes.length) { el.innerHTML = '<p class="ag-vazio">Sem lembretes. Cria um acima — por exemplo «Adubar as roseiras», todos os meses.</p>'; return; }
    var ord = lembretes.slice().sort(function (a, b) { return (a.data || "9") < (b.data || "9") ? -1 : 1; });
    el.innerHTML = ord.map(function (r) {
      var quando = r.rec === "sempre" ? "todos os dias" :
        (r.data ? (r.rec === "uma" ? fmt(r.data) : recDe(r.rec) + " (desde " + fmt(r.data) + ")") : recDe(r.rec));
      return '<article class="ag-lem"><span class="ag-lem-ic">🔔</span>' +
        '<div class="ag-lem-corpo"><strong>' + esc(r.titulo) + "</strong>" +
        '<span class="ag-lem-quando">' + esc(quando) + "</span>" +
        (r.nota ? '<span class="ag-lem-nota">' + esc(r.nota) + "</span>" : "") + "</div>" +
        '<button class="ag-apagar" data-del="' + r.id + '" aria-label="Apagar">✕</button></article>';
    }).join("");
  }
  function fmt(isoD) { var p = isoD.split("-"); return (+p[2]) + " " + MESES[+p[1] - 1].slice(0, 3) + " " + p[0]; }

  // ---------- Próximos dias ----------
  function renderProximos() {
    var el = document.getElementById("ag-proximos"); if (!el) return;
    var linhas = [];
    for (var i = 1; i <= 14; i++) {
      var dia = new Date(HOJE.getTime() + i * 86400000);
      var doDia = lembretes.filter(function (r) { return dueEm(r, dia); });
      doDia.forEach(function (r) {
        linhas.push({ dia: dia, titulo: r.titulo });
      });
    }
    if (!linhas.length) { el.innerHTML = '<p class="ag-vazio">Sem lembretes nos próximos 14 dias.</p>'; return; }
    el.innerHTML = linhas.map(function (l) {
      return '<div class="ag-prox"><span class="ag-prox-d">' + DIAS[l.dia.getDay()] + ", " + l.dia.getDate() + " " + MESES[l.dia.getMonth()].slice(0, 3) + "</span>" +
        '<span class="ag-prox-t">🔔 ' + esc(l.titulo) + "</span></div>";
    }).join("");
  }

  // ---------- Cabeçalho do dia ----------
  function renderCabecalho() {
    var el = document.getElementById("ag-dia"); if (!el) return;
    var lua = luaFase(), est = estacao();
    el.innerHTML = '<div class="ag-data-grande">' + DIAS[HOJE.getDay()] + ", " + HOJE.getDate() + " de " + MESES[HOJE.getMonth()] + "</div>" +
      '<div class="ag-dia-meta"><span>' + lua.ic + " " + lua.nome + '</span><span>' + est.i + " " + est.n + "</span></div>";
  }

  // ---------- Notificações (locais, ao abrir) ----------
  var notificou = false;
  function atualizarBotaoNotif() {
    var b = document.getElementById("ag-notif"); if (!b) return;
    if (typeof Notification === "undefined") { b.style.display = "none"; return; }
    if (Notification.permission === "granted") { b.textContent = "🔔 Notificações ativas"; b.classList.add("ativo"); }
    else if (Notification.permission === "denied") { b.textContent = "🔕 Notificações bloqueadas"; }
    else { b.textContent = "🔔 Ativar lembretes por notificação"; b.classList.remove("ativo"); }
  }
  function notificarHoje() {
    if (typeof Notification === "undefined" || Notification.permission !== "granted" || notificou) return;
    var strongs = document.querySelectorAll("#ag-hoje .ag-tarefa .ag-t-txt strong");
    var n = strongs.length; if (!n) return;
    notificou = true;
    try {
      var prim = Array.prototype.slice.call(strongs, 0, 3).map(function (e) { return e.textContent; }).join(" · ");
      new Notification("O Tio do Joca — hoje no campo", {
        body: n + " tarefa" + (n > 1 ? "s" : "") + " para hoje: " + prim,
        icon: "icon-192.png", badge: "icon-192.png", tag: "otj-hoje"
      });
    } catch (e) {}
  }

  function render() { renderCabecalho(); renderHoje(); renderLembretes(); renderProximos(); notificarHoje(); }

  document.addEventListener("click", function (e) {
    var t = e.target;
    if (t.id === "ag-add") { addLembrete(); return; }
    if (t.id === "ag-notif") {
      if (typeof Notification === "undefined") { alert("Este dispositivo não suporta notificações."); return; }
      Notification.requestPermission().then(function (p) {
        atualizarBotaoNotif();
        if (p === "granted") { notificou = false; notificarHoje(); }
      });
      return;
    }
    var d = t.closest && t.closest("[data-del]");
    if (d) { if (confirm("Apagar este lembrete?")) apagarLembrete(d.getAttribute("data-del")); return; }
  });
  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.matches && t.matches("input[data-feito]")) {
      alternarFeito(t.getAttribute("data-feito"));
      var l = t.closest("label"); if (l) l.classList.toggle("feita", t.checked);
      var p = document.querySelector(".ag-progresso");
      if (p) { // recontar
        var tot = document.querySelectorAll("#ag-hoje .ag-tarefa").length;
        var fe = document.querySelectorAll("#ag-hoje .ag-tarefa.feita").length;
        p.textContent = fe + " de " + tot + " concluído" + (tot > 1 ? "s" : "");
      }
    }
  });

  function iniciar() {
    var dd = document.getElementById("ag-data"); if (dd) dd.value = HOJE_ISO;
    atualizarBotaoNotif();
    render();
    pedirTempo();
    // as culturas podem carregar depois; re-render o "hoje" quando estiverem prontas
    setTimeout(renderHoje, 400);
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();
})();
