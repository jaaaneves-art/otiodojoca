/* O Tio do Joca — Service Worker
   Faz a app funcionar offline: guarda as páginas e recursos, serve-os
   sem rede, e mantém-se atualizado. */
const CACHE = "otj-v4";

const APP_SHELL = [
  "index.html", "offline.html",
  "volume-i.html", "volume-ii.html", "volume-iii.html", "volume-iv.html",
  "volume-v.html", "volume-vi.html", "volume-vii.html", "volume-viii.html",
  "volume-ix.html", "volume-x.html", "volume-xi.html", "volume-xii.html",
  "apendice.html",
  "culturas.html", "diario.html", "agenda.html", "plantas.html", "feiras.html",
  "style.css", "site.js", "search-data.js",
  "culturas.js", "diario.js", "agenda.js", "feiras.js", "tio-do-joca.js", "pwa-register.js",
  "logo.jpg", "logo.svg", "favicon.png",
  "icon-192.png", "icon-512.png", "icon-maskable-512.png",
  "og-image.jpg",
  "manifest.webmanifest"
];

self.addEventListener("install", (e) => {
  e.waitUntil(
    caches.open(CACHE).then((c) => c.addAll(APP_SHELL)).then(() => self.skipWaiting())
  );
});

self.addEventListener("activate", (e) => {
  e.waitUntil(
    caches.keys().then((keys) =>
      Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))
    ).then(() => self.clients.claim())
  );
});

self.addEventListener("fetch", (e) => {
  const req = e.request;
  if (req.method !== "GET") return;
  const url = new URL(req.url);

  // Navegação (abrir páginas): rede primeiro, cache como refúgio
  if (req.mode === "navigate") {
    e.respondWith(
      fetch(req)
        .then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        })
        .catch(() =>
          caches.match(req).then((r) => r || caches.match("offline.html") || caches.match("index.html"))
        )
    );
    return;
  }

  // Tipos de letra do Google (outro domínio): cache primeiro, guarda em tempo real
  if (url.hostname.indexOf("fonts.g") !== -1) {
    e.respondWith(
      caches.match(req).then((r) => r || fetch(req).then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(req, copy));
        return res;
      }).catch(() => r))
    );
    return;
  }

  // Recursos do próprio site: cache primeiro, senão rede (e guarda)
  if (url.origin === self.location.origin) {
    e.respondWith(
      caches.match(req).then((cached) =>
        cached ||
        fetch(req).then((res) => {
          const copy = res.clone();
          caches.open(CACHE).then((c) => c.put(req, copy));
          return res;
        }).catch(() => cached)
      )
    );
  }
});

// Permitir que a página peça uma atualização imediata
self.addEventListener("message", (e) => {
  if (e.data === "skipWaiting") self.skipWaiting();
});
