/* ============================================================
   O Tio do Joca — Acompanhamento de Culturas
   Biblioteca de ciclos agrícolas (Portugal continental) +
   seguimento pessoal guardado no aparelho (localStorage).
   Datas indicativas: no litoral norte atrasam ~2 semanas;
   no sul e interior quente, adiantam.
   ============================================================ */
(function () {
  "use strict";

  var MESES = ["", "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho",
    "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro"];

  // Cada fase: { m:[meses], t:"tarefa", d:"detalhe opcional" }
  var CULTURAS = {
    tomate: {
      nome: "Tomate", icone: "🍅", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em viveiro ou estufa", d: "Em tabuleiro, ao abrigo das geadas." },
        { m: [4], t: "Transplantar para o terreno", d: "Depois das últimas geadas, com o solo já morno." },
        { m: [5], t: "Colocar tutores e amarrar", d: "Guiar a planta e desladroar (tirar os ladrões)." },
        { m: [6], t: "Primeira adubação", d: "Composto ou adubo equilibrado; regar com regularidade." },
        { m: [7], t: "Vigiar o míldio", d: "Regar à base, nunca à folha; arejar." },
        { m: [8], t: "Colheita", d: "Colher à medida que amadurece." },
        { m: [9], t: "Fim de ciclo e limpeza", d: "Retirar as plantas e nutrir o solo." }
      ]
    },
    batata: {
      nome: "Batata", icone: "🥔", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Plantar a batata-semente", d: "Em regiões amenas já em fevereiro." },
        { m: [4], t: "Amontoa (chegar terra ao pé)", d: "Protege os tubérculos da luz." },
        { m: [5], t: "Adubar e vigiar o escaravelho", d: "Inspecionar as folhas por baixo." },
        { m: [6], t: "Vigiar o míldio", d: "Tempo húmido e quente é o de maior risco." },
        { m: [7, 8], t: "Colheita", d: "Quando a rama seca e tomba." }
      ]
    },
    cebola: {
      nome: "Cebola", icone: "🧅", cat: "Horta",
      fases: [
        { m: [9, 10], t: "Semear em viveiro (cebolo)", d: "Para transplantar mais tarde." },
        { m: [2, 3], t: "Transplantar", d: "Compasso largo para engrossar o bolbo." },
        { m: [4, 5], t: "Sachar e regar", d: "Manter limpo de ervas." },
        { m: [6, 7], t: "Colheita", d: "Quando a rama tomba; secar ao sol." }
      ]
    },
    alho: {
      nome: "Alho", icone: "🧄", cat: "Horta",
      fases: [
        { m: [10, 11], t: "Plantar os dentes", d: "Bico para cima; também se planta em janeiro." },
        { m: [2, 3], t: "Sachar", d: "Solo solto e sem ervas." },
        { m: [5], t: "Retirar as varas florais", d: "Assim o bolbo engrossa." },
        { m: [6], t: "Colheita", d: "Quando a folha amarelece; secar à sombra." }
      ]
    },
    couve: {
      nome: "Couve", icone: "🥬", cat: "Horta",
      fases: [
        { m: [3, 4], t: "Semear em viveiro", d: "Galega, tronchuda, lombarda…" },
        { m: [5], t: "Transplantar", d: "Enterrar bem o pé." },
        { m: [6, 7, 8], t: "Sachar e regar", d: "Vigiar a lagarta da couve." },
        { m: [10, 11, 12, 1], t: "Colheita", d: "A galega aguenta o inverno e melhora com a geada." }
      ]
    },
    alface: {
      nome: "Alface", icone: "🥗", cat: "Horta",
      fases: [
        { m: [2, 3, 4, 8, 9], t: "Semear (escalonado)", d: "Pouco de cada vez, todo o ano ameno." },
        { m: [3, 4, 5, 9, 10], t: "Transplantar", d: "Cerca de um mês após a sementeira." },
        { m: [4, 5, 6, 10, 11], t: "Colheita", d: "6 a 8 semanas depois; colher de manhã." }
      ]
    },
    feijao: {
      nome: "Feijão", icone: "🫘", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear", d: "Depois das geadas, solo morno." },
        { m: [6], t: "Tutorar e sachar", d: "O feijão-de-trepar precisa de canas." },
        { m: [7, 8], t: "Colheita em verde", d: "Vagem tenra e estaladiça." },
        { m: [9], t: "Colheita para grão seco", d: "Deixar secar a vagem na planta." }
      ]
    },
    abobora: {
      nome: "Abóbora", icone: "🎃", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear", d: "Em covas com estrume, ao sol." },
        { m: [6, 7, 8], t: "Regar e conduzir as ramas", d: "Dar espaço; regar à base." },
        { m: [9, 10], t: "Colheita e cura", d: "Cortar com pé; curar ao sol para guardar." }
      ]
    },
    pimento: {
      nome: "Pimento", icone: "🫑", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em ambiente quente", d: "Germina melhor com calor." },
        { m: [5], t: "Transplantar", d: "Depois das geadas." },
        { m: [6, 7], t: "Adubar e tutorar", d: "Regas regulares e sem encharcar." },
        { m: [8, 9], t: "Colheita", d: "Verde ou já corado." }
      ]
    },
    videira: {
      nome: "Videira", icone: "🍇", cat: "Vinha",
      fases: [
        { m: [1, 2], t: "Poda de inverno", d: "Com a planta em repouso." },
        { m: [3], t: "Empa e tratamento preventivo", d: "Preparar antes da rebentação." },
        { m: [4], t: "Rebentação — vigiar geadas tardias", d: "Os gomos são frágeis." },
        { m: [5], t: "Tratar (míldio/oídio) e despampar", d: "Arejar a folhagem." },
        { m: [6], t: "Floração", d: "Fase sensível ao tempo húmido." },
        { m: [7], t: "Pintor e poda verde", d: "As uvas começam a corar." },
        { m: [8], t: "Maturação", d: "Vigiar e proteger dos pássaros." },
        { m: [9], t: "Vindima", d: "Colher no ponto de açúcar certo." },
        { m: [10], t: "Queda da folha e descanso", d: "Fim do ciclo vegetativo." }
      ]
    },
    oliveira: {
      nome: "Oliveira", icone: "🫒", cat: "Olival",
      fases: [
        { m: [2, 3], t: "Poda", d: "Arejar a copa; retirar ramos secos." },
        { m: [4], t: "Adubação", d: "Antes da floração." },
        { m: [5], t: "Floração", d: "Não regar a mais nesta fase." },
        { m: [6], t: "Vingamento do fruto", d: "Cai a flor, forma-se a azeitona." },
        { m: [7, 8], t: "Vigiar a mosca-da-azeitona", d: "Armadilhas e monitorização." },
        { m: [11, 12], t: "Apanha da azeitona", d: "Para mesa mais cedo, para azeite mais tarde." }
      ]
    },
    macieira: {
      nome: "Macieira", icone: "🍎", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda de inverno", d: "Com a árvore sem folha." },
        { m: [3], t: "Tratamento pré-floração", d: "Preventivo antes de abrir a flor." },
        { m: [4], t: "Floração", d: "Vigiar geadas tardias." },
        { m: [5, 6], t: "Monda dos frutos", d: "Deixar menos frutos para os melhorar." },
        { m: [7, 8], t: "Regar e vigiar o bichado", d: "A lagarta que fura a maçã." },
        { m: [9, 10], t: "Colheita", d: "Conforme a variedade." }
      ]
    },
    citrinos: {
      nome: "Laranjeira / Citrinos", icone: "🍊", cat: "Pomar",
      fases: [
        { m: [3], t: "Adubação de primavera", d: "Arranque da nova rebentação." },
        { m: [4, 5], t: "Floração", d: "Perfume e vingamento." },
        { m: [6], t: "Monda natural — regar bem", d: "A árvore deixa cair o excesso." },
        { m: [7, 8], t: "Regas de verão", d: "Regulares no calor." },
        { m: [11, 12, 1, 2], t: "Colheita", d: "Amadurecem no fim do outono e inverno." }
      ]
    },
    roseira: {
      nome: "Roseira", icone: "🌹", cat: "Jardim",
      fases: [
        { m: [1, 2], t: "Poda", d: "Cortar acima de um gomo virado para fora." },
        { m: [3], t: "Adubar e tratar", d: "Prevenir oídio e afídeos." },
        { m: [4], t: "Rebentação", d: "Novas hastes e botões." },
        { m: [5, 6], t: "Primeira floração", d: "Limpar as flores murchas." },
        { m: [7, 8], t: "Regar e limpar", d: "À base, de manhã." },
        { m: [9, 10], t: "Segunda floração", d: "Nas variedades reflorescentes." }
      ]
    },
    tulipa: {
      nome: "Tulipa", icone: "🌷", cat: "Jardim",
      fases: [
        { m: [9, 10], t: "Comprar e plantar os bolbos", d: "Bico para cima, a 2–3 vezes a sua altura." },
        { m: [11], t: "Primeira rega", d: "Assentar a terra." },
        { m: [2], t: "Adubação", d: "Ao despontar as folhas." },
        { m: [3, 4], t: "Floração", d: "O espetáculo da primavera." },
        { m: [5], t: "Cortar a flor murcha", d: "Deixar secar a folha para alimentar o bolbo." },
        { m: [6], t: "Levantar e armazenar os bolbos", d: "Local seco e arejado até ao outono." }
      ]
    },

    curgete: {
      nome: "Curgete", icone: "🥒", cat: "Horta",
      fases: [
        { m: [4], t: "Semear", d: "Em viveiro ou no local, depois das geadas." },
        { m: [5], t: "Transplantar e desbastar", d: "Dar bastante espaço a cada planta." },
        { m: [6, 7], t: "Regar e adubar", d: "Gosta de água; colher os frutos ainda jovens." },
        { m: [8], t: "Colheita abundante", d: "Colher a miúdo para não abrandar a produção." },
        { m: [9], t: "Fim de ciclo", d: "Retirar as plantas e nutrir o solo." }
      ]
    },
    pepino: {
      nome: "Pepino", icone: "🥒", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear em ambiente quente", d: "Precisa de calor para germinar." },
        { m: [5, 6], t: "Transplantar e tutorar", d: "Conduzir numa rede ou canas." },
        { m: [7, 8], t: "Colheita regular", d: "Colher tenros, antes de amarelecerem." },
        { m: [9], t: "Fim de ciclo", d: "Terminada a produção, limpar." }
      ]
    },
    cenoura: {
      nome: "Cenoura", icone: "🥕", cat: "Horta",
      fases: [
        { m: [2, 3, 8, 9], t: "Semear direto (escalonado)", d: "Solo solto e sem pedras; primavera e fim de verão." },
        { m: [3, 4, 9, 10], t: "Desbastar", d: "Deixar espaço para a raiz engrossar." },
        { m: [4, 5, 10], t: "Sachar e regar", d: "Manter limpo de ervas." },
        { m: [6, 7, 11, 12], t: "Colheita", d: "Arrancar quando têm bom calibre." }
      ]
    },
    fava: {
      nome: "Fava", icone: "🫛", cat: "Horta",
      fases: [
        { m: [10, 11], t: "Semear", d: "Sementeira de outono, à portuguesa." },
        { m: [2], t: "Sachar e amontoar", d: "Chegar terra ao pé para aguentar o vento." },
        { m: [3], t: "Floração — despontar", d: "Cortar as pontas contra o afídeo-negro." },
        { m: [4, 5], t: "Colheita", d: "Colher tenras, para a panela." }
      ]
    },
    ervilha: {
      nome: "Ervilha", icone: "🫛", cat: "Horta",
      fases: [
        { m: [10, 11, 2], t: "Semear", d: "Outono ou fim de inverno; tempo fresco." },
        { m: [3], t: "Tutorar", d: "Rede ou ramos secos para trepar." },
        { m: [4, 5], t: "Colheita", d: "Colher em cheio, antes de endurecer." }
      ]
    },
    nabo: {
      nome: "Nabo e Grelos", icone: "🥬", cat: "Horta",
      fases: [
        { m: [8, 9], t: "Semear", d: "Para nabos e nabiças de inverno." },
        { m: [10, 11], t: "Colher nabiças", d: "Folhas jovens, tenras." },
        { m: [12, 1, 2], t: "Colher nabos e grelos", d: "Grelos são as hastes de flor, no fim." }
      ]
    },
    beringela: {
      nome: "Beringela", icone: "🍆", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em quente", d: "Como o tomate e o pimento." },
        { m: [5], t: "Transplantar", d: "Só depois das geadas, com calor." },
        { m: [6, 7], t: "Adubar e tutorar", d: "Regas regulares." },
        { m: [8, 9], t: "Colheita", d: "Colher com a casca ainda brilhante." }
      ]
    },
    brocolos: {
      nome: "Brócolos", icone: "🥦", cat: "Horta",
      fases: [
        { m: [6, 7], t: "Semear em viveiro", d: "Para colheita de outono/inverno." },
        { m: [8], t: "Transplantar", d: "Enterrar bem o pé." },
        { m: [9, 10], t: "Regar e sachar", d: "Vigiar a lagarta." },
        { m: [11, 12, 1, 2], t: "Colheita", d: "Cortar a cabeça central e depois os rebentos laterais." }
      ]
    },
    rabanete: {
      nome: "Rabanete", icone: "🔴", cat: "Horta",
      fases: [
        { m: [2, 3, 4, 9, 10], t: "Semear (escalonado)", d: "Cresce depressa; pouco de cada vez." },
        { m: [3, 4, 5, 10, 11], t: "Colheita", d: "4 a 6 semanas depois; evitar o calor forte, que os apimenta." }
      ]
    },
    beterraba: {
      nome: "Beterraba", icone: "🟣", cat: "Horta",
      fases: [
        { m: [3, 4, 8], t: "Semear", d: "Direto no local." },
        { m: [4, 5, 9], t: "Desbastar", d: "Cada semente dá várias plantas." },
        { m: [6, 7, 10, 11], t: "Colheita", d: "Quando têm bom tamanho; as folhas também se comem." }
      ]
    },
    espinafre: {
      nome: "Espinafre", icone: "🥬", cat: "Horta",
      fases: [
        { m: [9, 10, 2], t: "Semear", d: "Gosta de tempo fresco; espiga no calor." },
        { m: [10, 11, 12, 3, 4], t: "Colheita", d: "Cortar as folhas de fora, e deixa rebentar mais." }
      ]
    },
    milho: {
      nome: "Milho-doce", icone: "🌽", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear em bloco", d: "Depois das geadas; em quadrado, para polinizar bem." },
        { m: [6], t: "Sachar e amontoar", d: "Firmar o pé e regar." },
        { m: [7], t: "Adubar e regar na floração", d: "Fase de maior necessidade de água." },
        { m: [8, 9], t: "Colheita", d: "Quando o grão está leitoso e a barba seca." }
      ]
    },
    morango: {
      nome: "Morango", icone: "🍓", cat: "Horta",
      fases: [
        { m: [9, 10], t: "Plantar", d: "Em canteiro ou vaso, com o rebento à superfície." },
        { m: [2, 3], t: "Adubar e limpar", d: "Retirar folhas velhas e ervas." },
        { m: [4, 5, 6], t: "Floração e colheita", d: "Colher maduros, ao início do dia." },
        { m: [7], t: "Propagar pelos filhos", d: "Enraizar os estolhos para novas plantas." }
      ]
    },

    salsa: {
      nome: "Salsa", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [2, 3, 4, 8, 9], t: "Semear", d: "Germinação lenta; molhar a semente ajuda." },
        { m: [4, 5, 6, 7, 8, 9, 10], t: "Colher folhas", d: "Sempre as de fora, para rebentar do centro." },
        { m: [5, 6], t: "Deixar espigar para semente", d: "É bienal — floresce no 2.º ano." }
      ]
    },
    coentros: {
      nome: "Coentros", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4, 5, 8, 9], t: "Semear (escalonado)", d: "Espiga depressa no calor; semear a miúdo." },
        { m: [4, 5, 6, 9, 10], t: "Colher folhas", d: "4 a 6 semanas após a sementeira." },
        { m: [6, 7], t: "Colher a semente", d: "Deixar secar as umbelas na planta." }
      ]
    },
    manjericao: {
      nome: "Manjericão", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [4, 5], t: "Semear ou plantar", d: "Precisa de calor; é o manjerico dos Santos Populares." },
        { m: [6, 7, 8, 9], t: "Colher e pinçar as flores", d: "Tirar as flores faz a planta durar e engrossar." },
        { m: [10], t: "Fim de ciclo", d: "Gela com o frio; guardar semente." }
      ]
    },
    hortela: {
      nome: "Hortelã", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3], t: "Plantar ou dividir", d: "De preferência em vaso — é invasora." },
        { m: [4, 5, 6, 7, 8, 9, 10], t: "Colher e regar", d: "Gosta de solo húmido e meia-sombra." },
        { m: [10], t: "Cortar rente", d: "Renova a planta para o ano seguinte." }
      ]
    },

    figueira: {
      nome: "Figueira", icone: "🌳", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda leve", d: "A figueira pede pouca poda." },
        { m: [3], t: "Rebentação", d: "Arranque das folhas e dos primeiros figos." },
        { m: [6], t: "Figos lampos", d: "Primeira safra, nas variedades lampas." },
        { m: [8, 9], t: "Colheita principal (vindimos)", d: "Colher no ponto, quando pendem e amolecem." },
        { m: [11], t: "Queda da folha", d: "Entrada em repouso." }
      ]
    },
    pessegueiro: {
      nome: "Pessegueiro", icone: "🍑", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda e tratamento do crespão", d: "Calda bordalesa contra a lepra/crespão." },
        { m: [3], t: "Floração", d: "Floresce cedo; vigiar geadas." },
        { m: [4, 5], t: "Monda dos frutos", d: "Deixar menos frutos, para os melhorar." },
        { m: [6], t: "Regar e vigiar", d: "Necessita de água na engorda." },
        { m: [7, 8], t: "Colheita", d: "Conforme a variedade." }
      ]
    },
    ameixeira: {
      nome: "Ameixeira", icone: "🟣", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda", d: "Com a árvore em repouso." },
        { m: [3], t: "Floração", d: "Vigiar geadas tardias." },
        { m: [5], t: "Monda", d: "Aliviar a carga de frutos." },
        { m: [6, 7, 8], t: "Colheita", d: "Rainha-cláudia mais cedo; outras mais tarde." }
      ]
    },

    cerejeira: {
      nome: "Cerejeira", icone: "🍒", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda ligeira", d: "Pouca poda e em tempo seco, para evitar a gomose." },
        { m: [3], t: "Floração", d: "Vigiar geadas tardias." },
        { m: [4, 5], t: "Vingamento e rega", d: "Atenção à mosca-da-cereja." },
        { m: [5, 6], t: "Colheita", d: "Curta e intensa; proteger dos pássaros e da chuva, que racha o fruto." }
      ]
    },
    pereira: {
      nome: "Pereira", icone: "🍐", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda de inverno" },
        { m: [3], t: "Tratamento pré-floração" },
        { m: [4], t: "Floração", d: "Vigiar geadas." },
        { m: [5, 6], t: "Monda dos frutos" },
        { m: [7], t: "Regar e vigiar o pedrado" },
        { m: [8, 9], t: "Colheita", d: "Muitas pêras colhem-se firmes e amadurecem em casa." }
      ]
    },
    marmeleiro: {
      nome: "Marmeleiro", icone: "🟡", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda" },
        { m: [4], t: "Floração" },
        { m: [6, 7], t: "Regar e vigiar", d: "Atenção ao pedrado e à lagarta." },
        { m: [9, 10], t: "Colheita", d: "Perfumados; para marmelada e geleia." }
      ]
    },
    nespereira: {
      nome: "Nespereira", icone: "🟠", cat: "Pomar",
      fases: [
        { m: [10, 11], t: "Floração", d: "Floresce no outono, ao contrário das outras." },
        { m: [12, 1], t: "Proteger dos frios", d: "As geadas queimam os frutos pequenos." },
        { m: [3], t: "Aclarar os cachos", d: "Menos frutos, maiores." },
        { m: [4, 5], t: "Colheita", d: "Das primeiras frutas do ano." }
      ]
    },
    diospireiro: {
      nome: "Diospireiro", icone: "🟧", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda" },
        { m: [4], t: "Rebentação e floração" },
        { m: [6], t: "Monda", d: "Aliviar a carga, que parte os ramos." },
        { m: [10, 11], t: "Colheita", d: "Os do tipo mole acabam de amadurecer em casa." }
      ]
    },
    nogueira: {
      nome: "Nogueira", icone: "🌰", cat: "Pomar",
      fases: [
        { m: [8], t: "Poda (se necessária)", d: "Poda-se no fim do verão, nunca com a seiva a subir." },
        { m: [4], t: "Rebentação", d: "Tardia; vigiar geadas." },
        { m: [9, 10], t: "Colheita", d: "Apanhar as nozes caídas; secar à sombra." }
      ]
    },
    amendoeira: {
      nome: "Amendoeira", icone: "🌸", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Floração", d: "A primeira árvore a florir; anuncia o fim do inverno." },
        { m: [2, 3], t: "Poda", d: "Depois da floração." },
        { m: [6, 7], t: "Regar e vigiar", d: "Atenção à vespa e aos fungos." },
        { m: [8, 9], t: "Colheita", d: "Quando o casco abre." }
      ]
    },
    castanheiro: {
      nome: "Castanheiro", icone: "🌰", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda de inverno" },
        { m: [6, 7], t: "Floração" },
        { m: [10, 11], t: "Colheita", d: "Apanhar as castanhas dos ouriços caídos." }
      ]
    },
    romazeira: {
      nome: "Romãzeira", icone: "🔴", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Poda", d: "Controlar os rebentos da base." },
        { m: [5, 6], t: "Floração", d: "Flores vermelhas vistosas." },
        { m: [9, 10], t: "Colheita", d: "Colher antes que rachem com a chuva." }
      ]
    },
    kiwi: {
      nome: "Kiwi", icone: "🥝", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda de inverno", d: "Numa latada; é uma trepadeira vigorosa." },
        { m: [4], t: "Rebentação", d: "Vigiar geadas tardias." },
        { m: [5, 6], t: "Floração", d: "Precisa de planta macho e fêmea para vingar." },
        { m: [7, 8], t: "Regar muito", d: "Planta sedenta no calor." },
        { m: [10, 11], t: "Colheita", d: "Firmes; amadurecem depois em casa." }
      ]
    },

    couveflor: {
      nome: "Couve-flor", icone: "🥦", cat: "Horta",
      fases: [
        { m: [6, 7], t: "Semear em viveiro" },
        { m: [8], t: "Transplantar" },
        { m: [9, 10], t: "Regar e sachar", d: "Quer solo rico e fresco." },
        { m: [11, 12, 1, 2], t: "Colheita", d: "Dobrar as folhas sobre a cabeça para a manter branca." }
      ]
    },
    alhofrances: {
      nome: "Alho-francês", icone: "🥬", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em viveiro" },
        { m: [5, 6], t: "Transplantar fundo", d: "Enterrar bem o pé para embranquecer." },
        { m: [8, 9], t: "Amontoar terra", d: "Chega mais branco à mesa." },
        { m: [10, 11, 12, 1, 2], t: "Colheita", d: "Arranca-se conforme o preciso." }
      ]
    },
    melao: {
      nome: "Melão", icone: "🍈", cat: "Horta",
      fases: [
        { m: [4], t: "Semear em quente" },
        { m: [5], t: "Transplantar", d: "Local soalheiro e quente." },
        { m: [6, 7], t: "Conduzir e regar", d: "Aliviar a rega quando incham, para o açúcar." },
        { m: [8, 9], t: "Colheita", d: "Pelo perfume e pela casca que estala junto ao pé." }
      ]
    },
    melancia: {
      nome: "Melancia", icone: "🍉", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear em quente" },
        { m: [5, 6], t: "Transplantar", d: "Muito espaço e sol." },
        { m: [7], t: "Regar e conduzir", d: "Reduzir a água no fim, para adoçar." },
        { m: [8, 9], t: "Colheita", d: "Quando a gavinha junto ao fruto seca e soa a oco." }
      ]
    },
    graobico: {
      nome: "Grão-de-bico", icone: "🟤", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear", d: "Resiste bem ao seco." },
        { m: [4, 5], t: "Sachar", d: "Não gosta de excesso de água." },
        { m: [6, 7], t: "Colheita", d: "Arrancar a planta quando seca." }
      ]
    },
    batatadoce: {
      nome: "Batata-doce", icone: "🍠", cat: "Horta",
      fases: [
        { m: [5], t: "Plantar os rebentos", d: "Em camalhão, com calor." },
        { m: [6, 7, 8], t: "Regar e conduzir a rama" },
        { m: [10], t: "Colheita", d: "Antes das geadas; curar ao calor para adoçar." }
      ]
    },

    alecrim: {
      nome: "Alecrim", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Estaca ou planta; sol pleno e solo drenado." },
        { m: [5, 6, 7, 8, 9], t: "Colher raminhos", d: "Sol e pouca água dão mais aroma." },
        { m: [6], t: "Podar após florir", d: "Manter compacto, sem cortar na madeira velha." }
      ]
    },
    tomilho: {
      nome: "Tomilho", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar ou semear" },
        { m: [6, 7], t: "Colher na floração", d: "O aroma é máximo quando floresce." },
        { m: [3], t: "Dividir as touceiras velhas" }
      ]
    },
    oregaos: {
      nome: "Oregãos", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar ou semear" },
        { m: [7, 8], t: "Colher na floração", d: "Cortar e secar em molhos à sombra." },
        { m: [11], t: "Cortar rente", d: "Rebrota na primavera." }
      ]
    },
    cebolinho: {
      nome: "Cebolinho", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3], t: "Semear ou dividir" },
        { m: [4, 5, 6, 7, 8, 9, 10], t: "Cortar as folhas", d: "Corta-se rente e rebrota." },
        { m: [5, 6], t: "Flores comestíveis", d: "As flores roxas também se comem." }
      ]
    },

    sardinheira: {
      nome: "Sardinheira (Gerânio)", icone: "🌺", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "A flor dos peitoris e das varandas portuguesas." },
        { m: [5, 6, 7, 8, 9], t: "Regar e limpar flores murchas", d: "Tirar o que seca faz florir mais." },
        { m: [10], t: "Estacas para o ano seguinte", d: "Enraízam com facilidade." },
        { m: [12, 1], t: "Proteger do frio intenso", d: "Não gosta de geada forte." }
      ]
    },
    hortensia: {
      nome: "Horténsia", icone: "💠", cat: "Jardim",
      fases: [
        { m: [2, 3], t: "Poda", d: "Cortar as flores secas até ao primeiro par de gomos gordos." },
        { m: [4], t: "Adubar", d: "Solo ácido dá flores azuis; alcalino, cor-de-rosa." },
        { m: [6, 7, 8], t: "Regar bem, em meia-sombra", d: "Murcha depressa ao sol e à seca." },
        { m: [10], t: "Estacas", d: "Fáceis de enraizar." }
      ]
    },
    lavanda: {
      nome: "Lavanda", icone: "💜", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Sol pleno e solo seco e pobre." },
        { m: [6, 7], t: "Colher as espigas", d: "Ao começar a abrir a flor, para secar." },
        { m: [8], t: "Poda de manutenção", d: "Aparar sem cortar na madeira velha." }
      ]
    },
    girassol: {
      nome: "Girassol", icone: "🌻", cat: "Jardim",
      fases: [
        { m: [4, 5], t: "Semear", d: "Direto no local, ao sol." },
        { m: [6, 7], t: "Tutorar os mais altos", d: "Precisam de estaca com vento." },
        { m: [8, 9], t: "Floração e sementes", d: "Deixar secar o capítulo para colher a semente — e alimentar os pássaros." }
      ]
    },

    acelga: {
      nome: "Acelga", icone: "🥬", cat: "Horta",
      fases: [
        { m: [2, 3, 8, 9], t: "Semear", d: "Primavera e fim de verão." },
        { m: [3, 4, 9, 10], t: "Desbastar", d: "Dar espaço a cada planta." },
        { m: [5, 6, 7, 10, 11, 12], t: "Colher folhas de fora", d: "Rebenta continuamente durante meses." }
      ]
    },
    rucula: {
      nome: "Rúcula", icone: "🌱", cat: "Horta",
      fases: [
        { m: [2, 3, 4, 9, 10], t: "Semear (escalonado)", d: "Cresce depressa; espiga no calor." },
        { m: [3, 4, 5, 10, 11], t: "Colheita", d: "As folhas jovens são mais suaves." }
      ]
    },
    agriao: {
      nome: "Agrião", icone: "🌿", cat: "Horta",
      fases: [
        { m: [3, 4, 9], t: "Semear em local húmido", d: "Água corrente ou solo encharcado, meia-sombra." },
        { m: [4, 5, 6, 10, 11], t: "Colher os raminhos", d: "Rebrota depois de cortado." }
      ]
    },
    aipo: {
      nome: "Aipo", icone: "🥬", cat: "Horta",
      fases: [
        { m: [3, 4], t: "Semear em viveiro", d: "Germinação lenta." },
        { m: [5, 6], t: "Transplantar" },
        { m: [7, 8], t: "Regar muito e amontoar", d: "Chegar terra para embranquecer os pés." },
        { m: [9, 10, 11], t: "Colheita" }
      ]
    },
    funcho: {
      nome: "Funcho", icone: "🌿", cat: "Horta",
      fases: [
        { m: [6, 7, 8], t: "Semear", d: "Semear já tarde para não espigar." },
        { m: [8, 9], t: "Amontoar terra ao bolbo", d: "Para engrossar branco e tenro." },
        { m: [10, 11], t: "Colheita" }
      ]
    },
    alcachofra: {
      nome: "Alcachofra", icone: "🌵", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Plantar rebentos", d: "Ou dividir touceiras já existentes." },
        { m: [4, 5], t: "Colheita", d: "Cortar os capítulos ainda fechados." },
        { m: [9, 10], t: "Adubar e limpar", d: "Planta vivaz — produz vários anos." }
      ]
    },
    espargos: {
      nome: "Espargos", icone: "🌱", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Plantar as garras", d: "Numa vala funda; é uma cultura para muitos anos." },
        { m: [3, 4, 5], t: "Colher os turiões", d: "Só a partir do 2.º/3.º ano; parar em maio." },
        { m: [6, 7, 8], t: "Deixar a rama crescer", d: "Alimenta a planta para o ano seguinte." },
        { m: [11], t: "Cortar a rama seca e adubar" }
      ]
    },
    chuchu: {
      nome: "Chuchu", icone: "🥒", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Plantar o fruto germinado", d: "Enterrar o próprio chuchu já rebentado." },
        { m: [6, 7, 8], t: "Conduzir numa latada e regar", d: "Trepadeira vigorosa; muito espaço." },
        { m: [9, 10, 11], t: "Colheita", d: "Farta, até às primeiras geadas." }
      ]
    },

    damasqueiro: {
      nome: "Damasqueiro", icone: "🍑", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda", d: "Pouca poda e em tempo seco (sensível à gomose)." },
        { m: [2, 3], t: "Floração", d: "Cedo; muito sensível às geadas." },
        { m: [4, 5], t: "Monda" },
        { m: [6, 7], t: "Colheita" }
      ]
    },
    aveleira: {
      nome: "Aveleira", icone: "🌰", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Floração", d: "Flores discretas em pleno inverno." },
        { m: [2], t: "Poda e controlo de rebentos" },
        { m: [8, 9], t: "Colheita", d: "Apanhar as avelãs caídas." }
      ]
    },
    amoreira: {
      nome: "Amoreira", icone: "🫐", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda" },
        { m: [3, 4], t: "Rebentação" },
        { m: [5, 6], t: "Colheita", d: "Frutos frágeis; colher a miúdo — mancham muito." }
      ]
    },
    framboesa: {
      nome: "Framboesa", icone: "🍇", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Plantar e adubar", d: "Tutorar numa rede ou arame." },
        { m: [6, 7, 8], t: "Colheita", d: "Colher maduras de dois em dois dias." },
        { m: [11, 12], t: "Poda", d: "Cortar as canas que já frutificaram." }
      ]
    },
    mirtilo: {
      nome: "Mirtilo", icone: "🫐", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Plantar em solo ácido", d: "Precisa de terra ácida (turfa); o vaso é boa opção." },
        { m: [4], t: "Floração" },
        { m: [6, 7, 8], t: "Colheita", d: "Colher bem azuis, já sem verde." },
        { m: [11], t: "Poda ligeira e acidificar o solo" }
      ]
    },

    louro: {
      nome: "Louro", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Rústico; cresce devagar, também vive em vaso." },
        { m: [5, 6, 7, 8, 9], t: "Colher as folhas", d: "Melhores no tempo seco; secam muito bem." },
        { m: [6], t: "Poda de forma" }
      ]
    },
    ervacidreira: {
      nome: "Erva-cidreira", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Semear ou dividir" },
        { m: [5, 6, 7, 8, 9], t: "Colher para chá", d: "Mais aromática antes de florir." },
        { m: [10], t: "Cortar rente", d: "Rebrota vigorosa; é expansiva, convém controlar." }
      ]
    },
    camomila: {
      nome: "Camomila", icone: "🌼", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Semear" },
        { m: [5, 6], t: "Colher as flores", d: "Apanhar as flores abertas, para secar (chá)." },
        { m: [9], t: "Deixar ressemear", d: "Semeia-se sozinha para o ano seguinte." }
      ]
    },

    camelia: {
      nome: "Camélia", icone: "🌺", cat: "Jardim",
      fases: [
        { m: [11, 12, 1, 2, 3], t: "Floração", d: "A rainha do inverno; meia-sombra e solo ácido." },
        { m: [4], t: "Poda ligeira após florir" },
        { m: [6, 7, 8], t: "Regar em meia-sombra", d: "Nunca deixar secar por completo." }
      ]
    },
    dalia: {
      nome: "Dália", icone: "🌸", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar os tubérculos", d: "Depois das geadas." },
        { m: [6], t: "Tutorar e despontar", d: "Dá mais flores e hastes fortes." },
        { m: [7, 8, 9, 10], t: "Floração", d: "Cortar as murchas prolonga a floração." },
        { m: [11], t: "Levantar e guardar os tubérculos", d: "Nas zonas frias; secos, ao abrigo da geada." }
      ]
    },
    amorperfeito: {
      nome: "Amor-perfeito", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [9, 10], t: "Semear ou plantar", d: "Flor de outono, inverno e primavera; aguenta o frio." },
        { m: [11, 12, 1, 2, 3, 4], t: "Floração", d: "Tirar as murchas mantém-no a florir." },
        { m: [3], t: "Adubar" }
      ]
    },
    narciso: {
      nome: "Narciso", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [9, 10], t: "Plantar os bolbos", d: "No outono, a 2–3 vezes a sua altura." },
        { m: [2, 3], t: "Floração", d: "Dos primeiros anúncios da primavera." },
        { m: [4, 5], t: "Deixar secar a folha", d: "Não cortar verde — alimenta o bolbo para o ano." }
      ]
    },

    malagueta: {
      nome: "Malagueta / Piri-piri", icone: "🌶️", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em ambiente quente", d: "Germina devagar; precisa de calor." },
        { m: [5], t: "Transplantar", d: "Depois das geadas, ao sol." },
        { m: [6, 7], t: "Adubar e regar" },
        { m: [8, 9, 10], t: "Colheita", d: "Verde ou já vermelha; mais picante quanto mais madura." }
      ]
    },
    couvebruxelas: {
      nome: "Couve-de-bruxelas", icone: "🥬", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear em viveiro" },
        { m: [6, 7], t: "Transplantar", d: "Compasso largo; enterrar bem o pé." },
        { m: [8, 9], t: "Amontoar e vigiar a lagarta" },
        { m: [11, 12, 1, 2], t: "Colheita", d: "De baixo para cima; a geada torna-as mais doces." }
      ]
    },
    quiabo: {
      nome: "Quiabo", icone: "🫛", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear em quente", d: "Gosta muito de calor." },
        { m: [6], t: "Transplantar" },
        { m: [7, 8, 9], t: "Colheita", d: "Colher tenros, de 2 em 2 dias, antes de fibrosos." }
      ]
    },
    tremoco: {
      nome: "Tremoço", icone: "🟡", cat: "Horta",
      fases: [
        { m: [10, 11], t: "Semear", d: "Também melhora o solo — fixa o azoto." },
        { m: [3], t: "Sachar" },
        { m: [5, 6], t: "Colheita", d: "Curar em água e sal vários dias antes de comer (são amargos)." }
      ]
    },

    ginjeira: {
      nome: "Ginjeira", icone: "🍒", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda ligeira", d: "Como a cerejeira, com cuidado." },
        { m: [3], t: "Floração" },
        { m: [5, 6], t: "Colheita", d: "Ácidas; para compota e para a ginjinha." }
      ]
    },
    medronheiro: {
      nome: "Medronheiro", icone: "🔴", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Poda ligeira", d: "Arbusto rústico, resiste à seca e ao fogo." },
        { m: [10, 11], t: "Floração", d: "Floresce ao mesmo tempo que amadurece o fruto do ano anterior." },
        { m: [11, 12], t: "Colheita", d: "Medronhos maduros e moles; para doce e aguardente." }
      ]
    },
    sabugueiro: {
      nome: "Sabugueiro", icone: "⚪", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda", d: "Cresce muito; convém controlar." },
        { m: [4, 5], t: "Colher as flores", d: "Para xarope e filhoses; corolas abertas e perfumadas." },
        { m: [8, 9], t: "Colher as bagas", d: "Só maduras e sempre cozinhadas — cruas fazem mal." }
      ]
    },
    nectarina: {
      nome: "Nectarina", icone: "🍑", cat: "Pomar",
      fases: [
        { m: [1, 2], t: "Poda e tratar o crespão", d: "Como o pessegueiro — é uma pêssega de pele lisa." },
        { m: [3], t: "Floração", d: "Cedo; vigiar geadas." },
        { m: [4, 5], t: "Monda" },
        { m: [6, 7], t: "Colheita" }
      ]
    },
    groselha: {
      nome: "Groselha", icone: "🔴", cat: "Pomar",
      fases: [
        { m: [2], t: "Poda", d: "Arbusto; renovar as canas velhas." },
        { m: [4], t: "Floração" },
        { m: [6, 7], t: "Colheita", d: "Cachos maduros — vermelha, preta ou branca." }
      ]
    },
    maracuja: {
      nome: "Maracujá", icone: "🟣", cat: "Pomar",
      fases: [
        { m: [4, 5], t: "Plantar", d: "Trepadeira de clima ameno; numa latada ao sol." },
        { m: [6, 7], t: "Conduzir e regar" },
        { m: [9, 10, 11], t: "Floração e colheita", d: "Colher quando o fruto enruga e cai." }
      ]
    },
    bananeira: {
      nome: "Bananeira", icone: "🍌", cat: "Pomar",
      fases: [
        { m: [3, 4], t: "Plantar rebentos", d: "Só em clima ameno: Madeira, Algarve, litoral abrigado." },
        { m: [5, 6, 7, 8], t: "Regar muito e adubar", d: "Sedenta e gulosa; proteger do vento." },
        { m: [9, 10], t: "Colher o cacho", d: "Verde, para amadurecer depois; corta-se o pé após frutificar." },
        { m: [12, 1], t: "Proteger do frio", d: "Não tolera geada." }
      ]
    },
    abacateiro: {
      nome: "Abacateiro", icone: "🥑", cat: "Pomar",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Litoral ameno, ao abrigo do vento e da geada." },
        { m: [6, 7, 8], t: "Regar sem encharcar", d: "A raiz é sensível ao excesso de água." },
        { m: [10, 11, 12, 1], t: "Colheita", d: "Conforme a variedade; amadurece depois de colhido." }
      ]
    },

    salva: {
      nome: "Salva", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Sol e solo seco; rústica mediterrânica." },
        { m: [5, 6, 7, 8, 9], t: "Colher folhas" },
        { m: [6], t: "Podar após a floração", d: "Manter compacta." }
      ]
    },
    poejo: {
      nome: "Poejo", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Solo húmido e fresco; é da família da hortelã." },
        { m: [6, 7, 8], t: "Colher", d: "Para chá e para temperar os caracóis." },
        { m: [9], t: "Cortar rente" }
      ]
    },
    lucialima: {
      nome: "Lúcia-lima", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [4], t: "Plantar", d: "Ao sol; perde a folha no inverno." },
        { m: [6, 7, 8, 9], t: "Colher folhas", d: "Aroma intenso a limão, para chá." },
        { m: [2], t: "Podar", d: "No fim do inverno, antes de rebentar." }
      ]
    },
    endro: {
      nome: "Endro (Aneto)", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4, 8], t: "Semear", d: "Direto; não gosta de ser transplantado." },
        { m: [5, 6, 9], t: "Colher folhas" },
        { m: [7], t: "Colher a semente", d: "Deixar secar as umbelas." }
      ]
    },

    cravo: {
      nome: "Cravo", icone: "🌷", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Sol e boa drenagem." },
        { m: [5, 6, 7, 8, 9], t: "Floração", d: "Tirar as murchas prolonga a flor." },
        { m: [10], t: "Estacas", d: "Para novas plantas no ano seguinte." }
      ]
    },
    calendula: {
      nome: "Calêndula (Malmequer)", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [9, 10, 2, 3], t: "Semear", d: "Fácil; semeia-se sozinha para o ano." },
        { m: [4, 5, 6, 10, 11], t: "Floração", d: "Amarela/laranja; também medicinal." },
        { m: [6], t: "Colher as flores", d: "Para secar (pele) e afastar pragas na horta." }
      ]
    },
    petunia: {
      nome: "Petúnia", icone: "🌸", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Sol; ótima em jardineiras e varandas." },
        { m: [5, 6, 7, 8, 9], t: "Floração", d: "Regar e tirar as murchas para florir sem parar." }
      ]
    },
    crisantemo: {
      nome: "Crisântemo", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar ou dividir" },
        { m: [6], t: "Despontar", d: "Cortar as pontas para dar mais flores." },
        { m: [10, 11], t: "Floração", d: "A flor do outono e do Dia de Todos-os-Santos." }
      ]
    },
    gladiolo: {
      nome: "Gladíolo", icone: "🌺", cat: "Jardim",
      fases: [
        { m: [3, 4, 5], t: "Plantar os bolbos (escalonado)", d: "De 15 em 15 dias, para florir todo o verão." },
        { m: [6, 7, 8, 9], t: "Floração", d: "Tutorar as varas altas." },
        { m: [10], t: "Levantar e guardar os bolbos" }
      ]
    },
    jasmim: {
      nome: "Jasmim", icone: "🤍", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Trepadeira perfumada; sol ou meia-sombra." },
        { m: [6, 7, 8, 9], t: "Floração", d: "O perfume das noites de verão." },
        { m: [2], t: "Poda", d: "Conforme a espécie, no fim do inverno." }
      ]
    },
    buganvilia: {
      nome: "Buganvília", icone: "🌸", cat: "Jardim",
      fases: [
        { m: [4], t: "Plantar", d: "Muito sol e pouca água; sensível à geada." },
        { m: [6, 7, 8, 9], t: "Floração", d: "Dá mais flor quando se rega pouco." },
        { m: [2, 3], t: "Poda", d: "No fim do inverno; cuidado com os espinhos." }
      ]
    },
    lirio: {
      nome: "Lírio", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [10, 3], t: "Plantar os bolbos", d: "Outono ou fim de inverno, a 2–3 vezes a sua altura." },
        { m: [5, 6, 7], t: "Floração", d: "Perfumados; tirar as anteras evita nódoas." },
        { m: [8], t: "Deixar secar a folha", d: "Alimenta o bolbo para o ano seguinte." }
      ]
    },

    feijaofrade: {
      nome: "Feijão-frade", icone: "🫘", cat: "Horta",
      fases: [
        { m: [5, 6], t: "Semear", d: "Gosta de calor; resistente ao seco." },
        { m: [7], t: "Sachar e regar pouco" },
        { m: [8, 9], t: "Colheita", d: "Em verde ou deixar secar para grão." }
      ]
    },
    couverabano: {
      nome: "Couve-rábano", icone: "🥬", cat: "Horta",
      fases: [
        { m: [2, 3, 8], t: "Semear" },
        { m: [3, 4, 9], t: "Transplantar" },
        { m: [5, 6, 10, 11], t: "Colheita", d: "Colher o caule ainda tenro, do tamanho de uma laranja." }
      ]
    },
    cardo: {
      nome: "Cardo", icone: "🌿", cat: "Horta",
      fases: [
        { m: [4, 5], t: "Semear" },
        { m: [9, 10], t: "Embranquecer", d: "Atar as folhas e tapar 3 a 4 semanas para ficarem tenras." },
        { m: [11, 12], t: "Colheita", d: "Os pecíolos embranquecidos, para cozer." }
      ]
    },
    escarola: {
      nome: "Escarola / Chicória", icone: "🥬", cat: "Horta",
      fases: [
        { m: [7, 8], t: "Semear" },
        { m: [9], t: "Transplantar" },
        { m: [10, 11, 12], t: "Embranquecer e colher", d: "Tapar o coração uns dias antes, para tirar o amargo." }
      ]
    },
    physalis: {
      nome: "Physalis", icone: "🟠", cat: "Horta",
      fases: [
        { m: [2, 3], t: "Semear em quente" },
        { m: [5], t: "Transplantar", d: "Como o tomate; ao sol." },
        { m: [8, 9, 10], t: "Colheita", d: "Maduros quando o balão de papel seca e o fruto cai." }
      ]
    },

    limoeiro: {
      nome: "Limoeiro", icone: "🍋", cat: "Pomar",
      fases: [
        { m: [3], t: "Adubação de primavera" },
        { m: [4, 5], t: "Floração principal", d: "Refloresce várias vezes ao ano." },
        { m: [7, 8], t: "Regas de verão" },
        { m: [11, 12, 1, 2, 3], t: "Colheita", d: "Dá limões quase o ano inteiro." }
      ]
    },
    tangerineira: {
      nome: "Tangerineira / Clementina", icone: "🍊", cat: "Pomar",
      fases: [
        { m: [3], t: "Adubação" },
        { m: [4, 5], t: "Floração" },
        { m: [6], t: "Monda — regar bem" },
        { m: [11, 12, 1], t: "Colheita", d: "Doces no fim do outono e início do inverno." }
      ]
    },
    amorasilvestre: {
      nome: "Amora-silvestre", icone: "🫐", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Plantar e tutorar", d: "Numa rede; cuidado com os espinhos." },
        { m: [7, 8, 9], t: "Colheita", d: "Colher bem pretas e moles." },
        { m: [11], t: "Poda", d: "Cortar as canas que já deram fruto." }
      ]
    },
    alfarrobeira: {
      nome: "Alfarrobeira", icone: "🟤", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Poda de formação", d: "Árvore rústica do Sul; resiste bem à seca." },
        { m: [9, 10], t: "Floração" },
        { m: [8, 9], t: "Colheita", d: "Varejar as alfarrobas maduras (castanhas)." }
      ]
    },
    anoneira: {
      nome: "Anoneira (Anona)", icone: "🟢", cat: "Pomar",
      fases: [
        { m: [3], t: "Plantar / podar", d: "Só clima ameno sem geada (Madeira, litoral sul)." },
        { m: [6, 7], t: "Floração", d: "A polinização à mão melhora muito o vingamento." },
        { m: [11, 12, 1, 2], t: "Colheita", d: "Colher firme; amadurece em casa até ficar mole." }
      ]
    },
    goiabeira: {
      nome: "Goiabeira", icone: "🟩", cat: "Pomar",
      fases: [
        { m: [3, 4], t: "Plantar / podar", d: "Litoral ameno; sensível à geada forte." },
        { m: [5, 6], t: "Floração" },
        { m: [9, 10, 11], t: "Colheita", d: "Perfumadas quando cedem ao toque." }
      ]
    },
    feijoa: {
      nome: "Feijoa (Goiaba-serrana)", icone: "🟢", cat: "Pomar",
      fases: [
        { m: [2, 3], t: "Plantar / podar", d: "Arbusto rústico; tolera algum frio." },
        { m: [5, 6], t: "Floração", d: "As pétalas carnudas também se comem." },
        { m: [10, 11], t: "Colheita", d: "Deixar cair sozinhos, já maduros." }
      ]
    },
    papaieira: {
      nome: "Papaieira", icone: "🟠", cat: "Pomar",
      fases: [
        { m: [4, 5], t: "Plantar", d: "Só clima quente e sem geada (Madeira, Algarve abrigado, estufa)." },
        { m: [6, 7, 8], t: "Regar e adubar", d: "Cresce depressa e é gulosa." },
        { m: [9, 10, 11], t: "Colheita", d: "Quando a casca começa a amarelar." }
      ]
    },

    manjerona: {
      nome: "Manjerona", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Semear ou plantar", d: "Prima doce dos oregãos, mais delicada." },
        { m: [6, 7, 8], t: "Colher", d: "Antes e durante a floração." },
        { m: [10], t: "Cortar rente" }
      ]
    },
    estragao: {
      nome: "Estragão", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar por divisão", d: "Preferir o estragão-francês, mais aromático." },
        { m: [5, 6, 7, 8], t: "Colher folhas" },
        { m: [11], t: "Cortar e proteger", d: "Repousa no inverno." }
      ]
    },
    segurelha: {
      nome: "Segurelha", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Semear", d: "A companheira do feijão — afasta pragas." },
        { m: [6, 7, 8], t: "Colher", d: "Melhor na floração." },
        { m: [9], t: "Colher para secar" }
      ]
    },
    cerefolio: {
      nome: "Cerefólio", icone: "🌿", cat: "Aromáticas",
      fases: [
        { m: [2, 3, 9], t: "Semear", d: "Meia-sombra; espiga no calor." },
        { m: [4, 5, 10], t: "Colher folhas", d: "Aroma fino a anis; usar sempre fresco." }
      ]
    },
    hipericao: {
      nome: "Hipericão", icone: "🌼", cat: "Aromáticas",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Rústico; a erva-de-são-joão." },
        { m: [6, 7], t: "Colher em flor", d: "Pelo São João; para macerar em azeite (peles)." },
        { m: [10], t: "Cortar" }
      ]
    },

    begonia: {
      nome: "Begónia", icone: "🌸", cat: "Jardim",
      fases: [
        { m: [4, 5], t: "Plantar", d: "Meia-sombra; boa em vaso e canteiro." },
        { m: [6, 7, 8, 9], t: "Floração", d: "Regar sem molhar a folha." },
        { m: [11], t: "Recolher as tuberosas", d: "Guardar os tubérculos ao abrigo da geada." }
      ]
    },
    amarilis: {
      nome: "Amarílis", icone: "🌺", cat: "Jardim",
      fases: [
        { m: [10, 11], t: "Plantar o bolbo", d: "Deixar metade do bolbo à superfície." },
        { m: [2, 3, 4], t: "Floração", d: "Grandes flores; interior ou canteiro abrigado." },
        { m: [6, 7], t: "Repouso", d: "Deixar secar as folhas e descansar o bolbo." }
      ]
    },
    gerbera: {
      nome: "Gerbera", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Plantar", d: "Sol e boa drenagem; a coroa acima da terra." },
        { m: [5, 6, 7, 8, 9], t: "Floração", d: "Cortar flores e murchas prolonga." }
      ]
    },
    tagete: {
      nome: "Tagete (Cravo-túnico)", icone: "🌼", cat: "Jardim",
      fases: [
        { m: [3, 4], t: "Semear", d: "Ótimo na horta — afasta nemátodos e pragas." },
        { m: [5, 6, 7, 8, 9], t: "Floração", d: "Tirar as murchas mantém-no a florir." }
      ]
    },
    hibisco: {
      nome: "Hibisco", icone: "🌺", cat: "Jardim",
      fases: [
        { m: [4], t: "Plantar", d: "Sol; o de exterior tolera frio, o tropical não." },
        { m: [6, 7, 8, 9], t: "Floração", d: "Cada flor dura um dia, mas dá muitas." },
        { m: [2, 3], t: "Poda", d: "No fim do inverno." }
      ]
    },

    aloevera: {
      nome: "Aloé-vera", icone: "🪴", cat: "Suculentas",
      fases: [
        { m: [4, 5], t: "Plantar ou separar filhos", d: "Solo muito drenante; sol suave." },
        { m: [5, 6, 7, 8, 9], t: "Regar pouco", d: "Só quando a terra seca; nunca encharcar." },
        { m: [12, 1], t: "Proteger do frio e da chuva", d: "O gelo e o excesso de água apodrecem-na." }
      ]
    },
    crassula: {
      nome: "Crássula (Planta-jade)", icone: "🪴", cat: "Suculentas",
      fases: [
        { m: [4, 5], t: "Plantar ou estacas de folha", d: "Enraízam com muita facilidade." },
        { m: [5, 6, 7, 8, 9], t: "Regar muito pouco", d: "Guarda água nas folhas." },
        { m: [11, 12], t: "Abrigar do frio", d: "Interior ou local protegido no inverno." }
      ]
    },
    cato: {
      nome: "Cato", icone: "🌵", cat: "Suculentas",
      fases: [
        { m: [4, 5], t: "Plantar / mudar de vaso", d: "Substrato mineral, muito drenante." },
        { m: [5, 6, 7, 8], t: "Regar só quando seco", d: "Pouca água no verão; ao sol." },
        { m: [11, 12, 1, 2], t: "Repouso seco", d: "Quase sem regar e ao frio seco — ajuda a florir." }
      ]
    },
    agave: {
      nome: "Agave", icone: "🌵", cat: "Suculentas",
      fases: [
        { m: [4, 5], t: "Plantar ou separar rebentos", d: "Solo pobre e drenante; muito sol." },
        { m: [6, 7, 8], t: "Praticamente sem rega", d: "Extremamente resistente à seca." },
        { m: [1, 2], t: "Proteger da humidade fria", d: "Aguenta seco e frio, mas não o encharcamento." }
      ]
    }
  };

  // ---- Estado (localStorage) ----
  var K_SEG = "otj_culturas_seguidas";
  var K_TAR = "otj_culturas_tarefas";
  function ler(k, def) { try { return JSON.parse(localStorage.getItem(k)) || def; } catch (e) { return def; } }
  function guardar(k, v) { try { localStorage.setItem(k, JSON.stringify(v)); } catch (e) {} }
  var seguidas = ler(K_SEG, []);      // array de chaves
  var tarefas = ler(K_TAR, {});       // { chave: { idTarefa: true } }

  // ---- Região (zona por GPS) + relevo (manual) ----
  var K_REG = "otj_regiao", K_REG_AUTO = "otj_regiao_auto", K_RELEVO = "otj_relevo";
  var REGIOES = {
    norte:   { nome: "Norte",      sem: 3,  nota: "Norte e interior atrasam" },
    centro:  { nome: "Centro",     sem: 0,  nota: "calendário-base do continente" },
    sul:     { nome: "Sul",        sem: -3, nota: "Sul (Alentejo/Algarve) adianta" },
    madeira: { nome: "Madeira",    sem: -4, nota: "clima ameno todo o ano" },
    acores:  { nome: "Açores",     sem: 0,  nota: "clima oceânico suave" },
    base:    { nome: "Sem ajuste", sem: 0,  nota: "calendário-base" }
  };
  var RELEVOS = {
    litoral:  { nome: "Litoral",  sem: -1, nota: "costa amena, menos geadas e época mais longa" },
    interior: { nome: "Interior", sem: 0,  nota: "verões quentes, invernos frios e geadas tardias" },
    montanha: { nome: "Montanha", sem: 3,  nota: "frio de altitude: primavera tardia e outono cedo" }
  };
  var regiaoModo = ler(K_REG, "auto");    // auto|norte|centro|sul|madeira|acores|base
  var regiaoAuto = ler(K_REG_AUTO, null); // zona detetada por GPS
  var relevoModo = ler(K_RELEVO, "");     // ""|litoral|interior|montanha

  function detectarZona(lat, lon) {
    if (lon <= -20) return "acores";
    if (lat >= 32 && lat <= 33.5 && lon <= -16 && lon >= -18.2) return "madeira";
    if (lat >= 40.8) return "norte";
    if (lat >= 39.2) return "centro";
    return "sul";
  }
  function zonaEfetiva() {
    if (regiaoModo === "base") return "base";
    if (regiaoModo === "auto") return regiaoAuto; // null enquanto o GPS não responde
    return regiaoModo;
  }
  function semanasTotais() {
    if (regiaoModo === "base") return 0;
    var z = zonaEfetiva(), zs = (z && REGIOES[z]) ? REGIOES[z].sem : 0;
    var rs = (relevoModo && RELEVOS[relevoModo]) ? RELEVOS[relevoModo].sem : 0;
    return zs + rs;
  }
  function offsetMeses() { return Math.round(semanasTotais() / 4.345); }
  function mesAjustado(m) { return ((m - 1 + offsetMeses() + 12) % 12) + 1; }

  function pedirGPS() {
    if (!navigator.geolocation) { regiaoAuto = null; atualizarRegiaoBar(); return; }
    navigator.geolocation.getCurrentPosition(
      function (pos) { regiaoAuto = detectarZona(pos.coords.latitude, pos.coords.longitude); guardar(K_REG_AUTO, regiaoAuto); refrescar(); },
      function () { atualizarRegiaoBar(); },
      { timeout: 8000, maximumAge: 3600000 }
    );
  }
  function fraseDesvio() {
    var s = semanasTotais();
    if (!s) return "datas base";
    var a = Math.abs(s);
    return "~" + a + " semana" + (a > 1 ? "s" : "") + (s > 0 ? " mais tarde" : " mais cedo");
  }
  function notaAjuste() {
    var p = [], z = zonaEfetiva();
    if (regiaoModo !== "base" && z && REGIOES[z] && REGIOES[z].sem) p.push(REGIOES[z].nota);
    if (relevoModo && RELEVOS[relevoModo] && RELEVOS[relevoModo].sem) p.push(RELEVOS[relevoModo].nota);
    return p.join("; ");
  }
  function textoRegiao() {
    if (regiaoModo === "base") return "Sem ajuste — calendário-base";
    var z = zonaEfetiva();
    var rel = (relevoModo && RELEVOS[relevoModo]) ? " · " + RELEVOS[relevoModo].nome : "";
    if (regiaoModo === "auto" && !z) return "A detetar a tua região… (ou escolhe ao lado)";
    var prefixo = (regiaoModo === "auto") ? "📍 " : "";
    return prefixo + REGIOES[z].nome + rel + " — " + fraseDesvio();
  }
  function atualizarRegiaoBar() {
    var t = document.getElementById("rb-texto"); if (t) t.textContent = textoRegiao();
    var s = document.getElementById("rb-select"); if (s && s.value !== regiaoModo) s.value = regiaoModo;
    var r = document.getElementById("rb-relevo"); if (r && r.value !== relevoModo) r.value = relevoModo;
  }

  function estaSeguida(k) { return seguidas.indexOf(k) !== -1; }
  function alternarSeguir(k) {
    var i = seguidas.indexOf(k);
    if (i === -1) seguidas.push(k); else seguidas.splice(i, 1);
    guardar(K_SEG, seguidas);
  }
  function idTarefa(k, fi) { return k + "-" + fi; }
  function feita(k, fi) { return !!(tarefas[k] && tarefas[k][idTarefa(k, fi)]); }
  function alternarTarefa(k, fi) {
    if (!tarefas[k]) tarefas[k] = {};
    var id = idTarefa(k, fi);
    if (tarefas[k][id]) delete tarefas[k][id]; else tarefas[k][id] = true;
    guardar(K_TAR, tarefas);
  }

  function mesAtual() { return new Date().getMonth() + 1; }
  function esc(s) { return String(s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }

  // ---- "Este mês" — tarefas do mês atual das culturas seguidas ----
  function renderEsteMes() {
    var el = document.getElementById("este-mes");
    if (!el) return;
    var m = mesAtual();
    document.getElementById("mes-nome").textContent = MESES[m];
    if (!seguidas.length) {
      el.innerHTML = '<p class="cult-vazio">Ainda não segues nenhuma cultura. Escolhe uma na biblioteca abaixo e ela passa a aparecer aqui, com as tarefas do mês. 🌱</p>';
      return;
    }
    var linhas = [];
    seguidas.forEach(function (k) {
      var c = CULTURAS[k]; if (!c) return;
      c.fases.forEach(function (f, fi) {
        if (f.m.some(function (mm) { return mesAjustado(mm) === m; })) {
          var done = feita(k, fi);
          linhas.push(
            '<label class="cult-tarefa' + (done ? " feita" : "") + '">' +
            '<input type="checkbox" data-k="' + k + '" data-fi="' + fi + '"' + (done ? " checked" : "") + '>' +
            '<span class="ct-icone">' + c.icone + '</span>' +
            '<span class="ct-texto"><strong>' + esc(c.nome) + '</strong> — ' + esc(f.t) +
            (f.d ? '<em>' + esc(f.d) + "</em>" : "") + "</span></label>"
          );
        }
      });
    });
    el.innerHTML = linhas.length
      ? linhas.join("")
      : '<p class="cult-vazio">Nada urgente este mês nas tuas culturas — bom descanso! ☕</p>';
  }

  // ---- "As minhas culturas" ----
  function renderMinhas() {
    var el = document.getElementById("minhas-culturas");
    if (!el) return;
    if (!seguidas.length) { el.innerHTML = ""; return; }
    var m = mesAtual();
    el.innerHTML = seguidas.map(function (k) {
      var c = CULTURAS[k]; if (!c) return "";
      var total = c.fases.length, feitas = 0;
      c.fases.forEach(function (f, fi) { if (feita(k, fi)) feitas++; });
      var pct = Math.round((feitas / total) * 100);
      return '<article class="mc-card" data-abrir="' + k + '">' +
        '<span class="mc-icone">' + c.icone + "</span>" +
        '<div class="mc-info"><strong>' + esc(c.nome) + "</strong>" +
        '<span class="mc-cat">' + esc(c.cat) + "</span>" +
        '<div class="mc-barra"><i style="width:' + pct + '%"></i></div>' +
        '<span class="mc-pct">' + feitas + "/" + total + " tarefas</span></div></article>";
    }).join("");
  }

  // ---- Biblioteca ----
  function renderBiblioteca() {
    var el = document.getElementById("biblioteca");
    if (!el) return;
    var cats = {};
    Object.keys(CULTURAS).forEach(function (k) {
      var c = CULTURAS[k]; (cats[c.cat] = cats[c.cat] || []).push(k);
    });
    var html = "";
    Object.keys(cats).forEach(function (cat) {
      html += '<h3 class="bib-cat">' + esc(cat) + "</h3><div class=\"bib-grid\">";
      html += cats[cat].map(function (k) {
        var c = CULTURAS[k], seg = estaSeguida(k);
        return '<button class="bib-card' + (seg ? " seg" : "") + '" data-abrir="' + k + '">' +
          '<span class="bib-icone">' + c.icone + "</span>" +
          '<span class="bib-nome">' + esc(c.nome) + "</span>" +
          (seg ? '<span class="bib-badge">a seguir</span>' : "") + "</button>";
      }).join("");
      html += "</div>";
    });
    el.innerHTML = html;
  }

  // ---- Modal do ciclo anual ----
  function abrir(k) {
    var c = CULTURAS[k]; if (!c) return;
    var m = mesAtual();
    var porMes = {};
    c.fases.forEach(function (f, fi) { f.m.forEach(function (mm) { var am = mesAjustado(mm); (porMes[am] = porMes[am] || []).push({ f: f, fi: fi }); }); });
    var meses = "";
    for (var i = 1; i <= 12; i++) {
      if (!porMes[i]) continue;
      meses += '<div class="ciclo-mes' + (i === m ? " atual" : "") + '"><div class="cm-nome">' + MESES[i] +
        (i === m ? ' <span class="cm-tag">este mês</span>' : "") + "</div>";
      porMes[i].forEach(function (o) {
        var done = feita(k, o.fi);
        meses += '<label class="cm-tarefa' + (done ? " feita" : "") + '">' +
          '<input type="checkbox" data-k="' + k + '" data-fi="' + o.fi + '"' + (done ? " checked" : "") + ">" +
          "<span>" + esc(o.f.t) + (o.f.d ? '<em>' + esc(o.f.d) + "</em>" : "") + "</span></label>";
      });
      meses += "</div>";
    }
    var seg = estaSeguida(k);
    var mo = document.getElementById("modalCultura");
    mo.querySelector(".mo-corpo").innerHTML =
      '<div class="mo-cab"><span class="mo-icone">' + c.icone + "</span>" +
      "<div><h2>" + esc(c.nome) + '</h2><span class="mo-cat">' + esc(c.cat) + "</span></div>" +
      '<button class="mo-seguir' + (seg ? " seg" : "") + '" data-seguir="' + k + '">' +
      (seg ? "✓ A seguir" : "+ Acompanhar") + "</button></div>" +
      '<div class="ciclo">' + meses + "</div>" +
      '<p class="mo-nota">' + (semanasTotais() ? "Ajustado " + fraseDesvio() + " — " + notaAjuste() + "." : "Datas indicativas para Portugal continental.") + ' Aproximado: o teu terreno e o ano mandam sempre.</p>';
    mo.classList.add("open");
  }
  function fechar() { var mo = document.getElementById("modalCultura"); if (mo) mo.classList.remove("open"); }

  function refrescar() { renderEsteMes(); renderMinhas(); renderBiblioteca(); atualizarRegiaoBar(); }

  // ---- Eventos (delegação, robusto a timing) ----
  document.addEventListener("click", function (e) {
    var t = e.target;
    var ab = t.closest && t.closest("[data-abrir]");
    if (ab) { abrir(ab.getAttribute("data-abrir")); return; }
    if (t.matches && t.matches("[data-seguir]")) {
      var k = t.getAttribute("data-seguir");
      alternarSeguir(k);
      t.classList.toggle("seg"); t.textContent = estaSeguida(k) ? "✓ A seguir" : "+ Acompanhar";
      refrescar();
      return;
    }
    if (t.id === "modalFechar" || (t.classList && t.classList.contains("mo-fundo"))) { fechar(); return; }
  });
  document.addEventListener("keydown", function (e) { if (e.key === "Escape") fechar(); });
  document.addEventListener("change", function (e) {
    var t = e.target;
    if (t.id === "rb-relevo") {
      relevoModo = t.value; guardar(K_RELEVO, relevoModo); refrescar(); return;
    }
    if (t.id === "rb-select") {
      regiaoModo = t.value; guardar(K_REG, regiaoModo);
      if (regiaoModo === "auto") pedirGPS();
      refrescar(); return;
    }
    if (t.matches && t.matches('input[type="checkbox"][data-k]')) {
      alternarTarefa(t.getAttribute("data-k"), parseInt(t.getAttribute("data-fi"), 10));
      var lbl = t.closest("label"); if (lbl) lbl.classList.toggle("feita", t.checked);
      renderEsteMes(); renderMinhas();
    }
  });

  function iniciar() { refrescar(); if (regiaoModo === "auto") pedirGPS(); }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar);
  else iniciar();

  // API pública para a Agenda Rural (reutiliza a biblioteca e o ajuste de região)
  window.OTJ_AGRO = {
    mesAtual: mesAtual,
    temSeguidas: function () { return seguidas.length; },
    regiao: function () { return { texto: textoRegiao(), desvio: fraseDesvio() }; },
    tarefasHoje: function () {
      var m = mesAtual(), out = [];
      seguidas.forEach(function (k) {
        var c = CULTURAS[k]; if (!c) return;
        c.fases.forEach(function (f) {
          if (f.m.some(function (mm) { return mesAjustado(mm) === m; }))
            out.push({ chave: k, cultura: c.nome, icone: c.icone, tarefa: f.t, detalhe: f.d || "" });
        });
      });
      return out;
    }
  };
})();
