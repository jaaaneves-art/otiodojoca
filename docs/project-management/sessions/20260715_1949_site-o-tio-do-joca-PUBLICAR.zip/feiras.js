/* ============================================================
   O Tio do Joca — Feiras de Portugal (diretório)
   Núcleo curado das grandes feiras (anuais, francas, de gado,
   temáticas) e das feiras semanais mais conhecidas. Pensado
   para crescer: a lista completa das feiras semanais por
   concelho deve ser acrescentada a partir de fontes oficiais
   (câmaras municipais). tipo: semanal | quinzenal | anual |
   franca | gado | temática | velharias.
   ============================================================ */
(function () {
  "use strict";

  var FEIRAS = [
    // — Grandes feiras anuais / francas —
    { n: "Feira de Março", concelho: "Aveiro", distrito: "Aveiro", tipo: "anual", quando: "Março a Abril", nota: "Grande feira de comércio e diversões, com origem no séc. XV." },
    { n: "Feiras Novas", concelho: "Ponte de Lima", distrito: "Viana do Castelo", tipo: "franca", quando: "Setembro", nota: "Uma das mais antigas do país (foral de 1125); feira, festa e romaria." },
    { n: "Feira de São Mateus", concelho: "Viseu", distrito: "Viseu", tipo: "franca", quando: "Agosto a Setembro", nota: "Das mais antigas e longas de Portugal; comércio, gastronomia e diversão." },
    { n: "Feira de São Martinho", concelho: "Penafiel", distrito: "Porto", tipo: "anual", quando: "Novembro", nota: "Tradicional feira e festa de São Martinho." },
    { n: "Feira dos Santos", concelho: "Chaves", distrito: "Vila Real", tipo: "franca", quando: "Início de Novembro", nota: "Grande feira anual, com gado e produtos da terra." },
    { n: "Feira de São João", concelho: "Évora", distrito: "Évora", tipo: "anual", quando: "Junho", nota: "A feira grande do Alentejo, de comércio e festa." },
    { n: "Feira de São Gonçalo", concelho: "Amarante", distrito: "Porto", tipo: "anual", quando: "Junho", nota: "Feira e festa do santo casamenteiro, com os famosos bolos." },
    { n: "Feira de Nossa Senhora dos Remédios", concelho: "Lamego", distrito: "Viseu", tipo: "anual", quando: "Agosto a Setembro", nota: "Feira ligada à grande romaria do escadório." },
    { n: "Feira de Santa Iria", concelho: "Tomar", distrito: "Santarém", tipo: "anual", quando: "Outubro", nota: "Feira tradicional de outono." },

    // — Feiras de gado / agropecuárias —
    { n: "Feira Nacional do Cavalo", concelho: "Golegã", distrito: "Santarém", tipo: "gado", quando: "Novembro (São Martinho)", nota: "A grande feira do cavalo, entre a prova do vinho novo e a castanha." },
    { n: "Feira Nacional da Agricultura", concelho: "Santarém", distrito: "Santarém", tipo: "temática", quando: "Junho", nota: "A montra nacional da agricultura e da pecuária." },
    { n: "Ovibeja", concelho: "Beja", distrito: "Beja", tipo: "temática", quando: "Abril a Maio", nota: "A grande feira agropecuária do Alentejo." },

    // — Feiras temáticas —
    { n: "Feira do Fumeiro", concelho: "Vinhais", distrito: "Bragança", tipo: "temática", quando: "Fevereiro", nota: "Mostra do fumeiro e dos enchidos transmontanos." },
    { n: "Feira do Fumeiro", concelho: "Montalegre", distrito: "Vila Real", tipo: "temática", quando: "Inverno", nota: "Enchidos e produtos do porco do Barroso." },
    { n: "Feira da Castanha", concelho: "Marvão", distrito: "Portalegre", tipo: "temática", quando: "Novembro", nota: "Feira da castanha, na vila histórica de Marvão." },
    { n: "FATACIL", concelho: "Lagoa", distrito: "Faro", tipo: "temática", quando: "Agosto", nota: "Grande feira de artesanato, agricultura, turismo e comércio do Algarve." },

    // — Velharias / antiguidades —
    { n: "Feira da Ladra", concelho: "Lisboa", distrito: "Lisboa", tipo: "velharias", quando: "Terça e Sábado", nota: "A histórica feira de velharias, em Campo de Santa Clara." },

    // — Feiras semanais mais conhecidas —
    { n: "Feira de Barcelos", concelho: "Barcelos", distrito: "Braga", tipo: "semanal", quando: "Quinta-feira", nota: "A maior e mais famosa feira semanal do país; a louça e o galo de Barcelos." },
    { n: "Feira de Espinho", concelho: "Espinho", distrito: "Aveiro", tipo: "semanal", quando: "Segunda-feira", nota: "Grande feira semanal, junto ao mar." },
    { n: "Mercado de Estremoz", concelho: "Estremoz", distrito: "Évora", tipo: "semanal", quando: "Sábado", nota: "Célebre mercado de sábado no Rossio; louça, antiguidades e produtos da terra." },
    { n: "Feira da Malveira", concelho: "Mafra", distrito: "Lisboa", tipo: "semanal", quando: "Quinta-feira", nota: "Uma das maiores feiras populares da região de Lisboa." },
    { n: "Feira de Carcavelos", concelho: "Cascais", distrito: "Lisboa", tipo: "semanal", quando: "Quinta-feira", nota: "Grande feira de roupa, têxteis e calçado." },
    { n: "Feira de Loulé", concelho: "Loulé", distrito: "Faro", tipo: "semanal", quando: "Sábado", nota: "Feira e mercado, a par do mercado municipal árabe." },
    { n: "Feira de Ponte de Lima", concelho: "Ponte de Lima", distrito: "Viana do Castelo", tipo: "quinzenal", quando: "Segundas (de 15 em 15 dias)", nota: "Uma das feiras mais antigas de Portugal, à beira do Lima." }
  ];

  var TIPOS = {
    semanal: { n: "Semanal", i: "🗓️" }, quinzenal: { n: "Quinzenal", i: "🗓️" },
    anual: { n: "Anual", i: "🎪" }, franca: { n: "Franca", i: "🎪" },
    gado: { n: "Gado / Agropecuária", i: "🐎" }, temática: { n: "Temática", i: "🧺" },
    velharias: { n: "Velharias", i: "🕰️" }
  };

  function esc(s) { return String(s == null ? "" : s).replace(/[&<>"]/g, function (c) { return { "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]; }); }
  function norm(s) { try { return s.normalize("NFD").replace(/[\u0300-\u036f]/g, "").toLowerCase(); } catch (e) { return s.toLowerCase(); } }

  var fBusca = "", fDistrito = "", fTipo = "";

  function distritos() {
    var s = {}; FEIRAS.forEach(function (f) { s[f.distrito] = 1; });
    return Object.keys(s).sort();
  }

  function render() {
    var el = document.getElementById("fe-lista"); if (!el) return;
    var q = norm(fBusca);
    var lista = FEIRAS.filter(function (f) {
      if (fDistrito && f.distrito !== fDistrito) return false;
      if (fTipo && f.tipo !== fTipo) return false;
      if (q && norm(f.n + " " + f.concelho + " " + f.distrito + " " + f.quando).indexOf(q) === -1) return false;
      return true;
    }).sort(function (a, b) { return a.distrito === b.distrito ? a.n.localeCompare(b.n) : a.distrito.localeCompare(b.distrito); });

    var cnt = document.getElementById("fe-conta");
    if (cnt) cnt.textContent = lista.length + (lista.length === 1 ? " feira" : " feiras");

    if (!lista.length) { el.innerHTML = '<p class="fe-vazio">Nenhuma feira encontrada com estes filtros.</p>'; return; }
    var html = "", distAtual = "";
    lista.forEach(function (f) {
      if (f.distrito !== distAtual) { distAtual = f.distrito; html += '<h3 class="fe-dist">' + esc(f.distrito) + "</h3>"; }
      var t = TIPOS[f.tipo] || { n: f.tipo, i: "📍" };
      html += '<article class="fe-card"><span class="fe-ic">' + t.i + "</span>" +
        '<div class="fe-corpo"><div class="fe-top"><strong>' + esc(f.n) + "</strong>" +
        '<span class="fe-tipo">' + t.n + "</span></div>" +
        '<div class="fe-meta"><span class="fe-local">📍 ' + esc(f.concelho) + "</span>" +
        '<span class="fe-quando">🗓️ ' + esc(f.quando) + "</span></div>" +
        (f.nota ? '<div class="fe-nota">' + esc(f.nota) + "</div>" : "") +
        "</div></article>";
    });
    el.innerHTML = html;
  }

  document.addEventListener("input", function (e) { if (e.target.id === "fe-busca") { fBusca = e.target.value; render(); } });
  document.addEventListener("change", function (e) {
    if (e.target.id === "fe-distrito") { fDistrito = e.target.value; render(); }
    if (e.target.id === "fe-tipo") { fTipo = e.target.value; render(); }
  });

  function iniciar() {
    var sd = document.getElementById("fe-distrito");
    if (sd) sd.innerHTML = '<option value="">Todos os distritos</option>' + distritos().map(function (d) { return "<option>" + esc(d) + "</option>"; }).join("");
    var st = document.getElementById("fe-tipo");
    if (st) st.innerHTML = '<option value="">Todos os tipos</option>' + Object.keys(TIPOS).map(function (k) { return '<option value="' + k + '">' + TIPOS[k].n + "</option>"; }).join("");
    render();
  }
  if (document.readyState === "loading") document.addEventListener("DOMContentLoaded", iniciar); else iniciar();

  // permitir crescer o diretório a partir de dados externos (ex.: CSV das câmaras)
  window.OTJ_FEIRAS = { dados: FEIRAS, acrescentar: function (arr) { if (Array.isArray(arr)) { FEIRAS.push.apply(FEIRAS, arr); render(); } } };
})();
