/* O Tio do Joca — registo da PWA e botão de instalação (robusto) */
(function () {
  "use strict";

  // 1) Registar o service worker (funcionamento offline)
  if ("serviceWorker" in navigator) {
    window.addEventListener("load", function () {
      navigator.serviceWorker.register("sw.js").catch(function () {});
    });
  }

  // Se já está instalada (a correr como app), não mostrar nada
  var standalone = (window.matchMedia && window.matchMedia("(display-mode: standalone)").matches) ||
    window.navigator.standalone === true;
  if (standalone) return;

  var ESTILO = "position:fixed;left:16px;bottom:16px;z-index:2147483000;" +
    "background:#c23b22;color:#fff8e7;border:none;border-radius:24px;" +
    "padding:11px 18px;font-family:'IBM Plex Mono',monospace;font-size:.78rem;" +
    "letter-spacing:.5px;cursor:pointer;box-shadow:0 6px 20px rgba(0,0,0,.28);";

  function botao(texto, aoClicar) {
    var b = document.getElementById("otj-instalar");
    if (b) return b;
    b = document.createElement("button");
    b.id = "otj-instalar"; b.type = "button"; b.textContent = texto;
    b.setAttribute("aria-label", "Instalar a aplicação");
    b.style.cssText = ESTILO;
    b.addEventListener("click", aoClicar);
    (document.body || document.documentElement).appendChild(b);
    return b;
  }
  function remover() { var b = document.getElementById("otj-instalar"); if (b) b.remove(); }

  // 2) Chrome / Edge / Android: prompt nativo
  var deferido = null;
  window.addEventListener("beforeinstallprompt", function (e) {
    e.preventDefault();
    deferido = e;
    botao("\u2913 Instalar app", function () {
      if (!deferido) return;
      deferido.prompt();
      deferido.userChoice.finally(function () { deferido = null; remover(); });
    });
  });
  window.addEventListener("appinstalled", function () { deferido = null; remover(); });

  // 3) iPhone / iPad (Safari): nao ha prompt - mostrar instrucoes
  var ua = window.navigator.userAgent || "";
  var isIOS = /iPad|iPhone|iPod/.test(ua) ||
    (navigator.platform === "MacIntel" && navigator.maxTouchPoints > 1);
  var isSafari = /safari/i.test(ua) && !/crios|fxios|chrome|android|edg/i.test(ua);
  if (isIOS && isSafari) {
    window.addEventListener("load", function () {
      botao("\u2913 Instalar app", instrucoesIOS);
    });
  }

  function instrucoesIOS() {
    if (document.getElementById("otj-ios")) return;
    var cx = document.createElement("div");
    cx.id = "otj-ios";
    cx.style.cssText = "position:fixed;inset:0;z-index:2147483001;background:rgba(0,0,0,.55);" +
      "display:flex;align-items:flex-end;justify-content:center;padding:0 0 24px;";
    cx.innerHTML =
      '<div style="background:#faf3e0;color:#2b2018;max-width:420px;margin:0 14px;border-radius:16px;' +
      'padding:20px 22px;font-family:\'Source Serif 4\',serif;box-shadow:0 20px 50px rgba(0,0,0,.4)">' +
      '<div style="font-family:\'Fraunces\',serif;font-size:1.15rem;color:#c23b22;margin-bottom:8px">Instalar no iPhone</div>' +
      '<p style="margin:0 0 6px;line-height:1.6">1. Toca no botao <b>Partilhar</b> (o quadrado com a seta), em baixo.</p>' +
      '<p style="margin:0 0 6px;line-height:1.6">2. Desce e toca em <b>\u00abAdicionar ao ecra principal\u00bb</b>.</p>' +
      '<p style="margin:0 0 14px;line-height:1.6">3. Confirma em <b>\u00abAdicionar\u00bb</b> \u2014 e fica com o icone do Tio do Joca no telemovel.</p>' +
      '<button id="otj-ios-fechar" style="background:#c23b22;color:#fff8e7;border:none;border-radius:20px;' +
      'padding:9px 18px;font-family:\'IBM Plex Mono\',monospace;font-size:.75rem;cursor:pointer">Entendido</button></div>';
    document.body.appendChild(cx);
    cx.addEventListener("click", function (e) { if (e.target === cx || e.target.id === "otj-ios-fechar") cx.remove(); });
  }
})();
